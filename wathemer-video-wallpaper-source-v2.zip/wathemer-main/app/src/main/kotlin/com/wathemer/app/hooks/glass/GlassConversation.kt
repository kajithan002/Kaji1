// The conversation screen's chrome: the header capsule and band, the compose pill, and the list
// padding that lets rows scroll behind both. Geometry is re-derived per layout, never snapshotted at attach.
package com.wathemer.app.hooks.glass

import android.graphics.Rect
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewTreeObserver
import android.widget.AbsListView
import android.widget.FrameLayout
import com.wathemer.app.glass.GlassView
import com.wathemer.app.hooks.HookLog
import com.wathemer.app.hooks.waId
import de.robv.android.xposed.XposedBridge
import java.lang.ref.WeakReference
import java.util.WeakHashMap

internal var convHolderRef: WeakReference<ViewGroup>? = null

internal var convCoordRef: WeakReference<ViewGroup>? = null

internal var convFooterRef: WeakReference<ViewGroup>? = null

/** True while the floating menu's action card covers the compose row; the pill collapses under it. */
@Volatile internal var convSelectionCardShown = false

/** The strip above the messages, pinned message included; the floated toolbar sits over its whole height. */
internal var convBannerRef: WeakReference<ViewGroup>? = null

internal val convToolbarTag = tagKey("wathemer-conv-toolbar")

internal val convFooterTag = tagKey("wathemer-conv-footer")

private val convFloatTag = tagKey("wathemer-conv-float")

private val convBannerTag = tagKey("wathemer-conv-banner")

private val convDateTag = tagKey("wathemer-conv-date")

/** Where the header capsule ends inside the holder; the strip hangs off this, not off the holder's full height. */
private var convCapsuleBottom = -1

// Weak values: a pane reaches its owner through the view tree, and a strong value would pin every dead chat's tree.
private val convPanes = WeakHashMap<View, WeakReference<GlassView>>()

private val convRect = Rect()

/** Trimmed off the Back button's band before the capsule is grown past it. */
private const val CONV_PILL_TRIM_DP = 4f

/** Deliberately more than fits: both clamps engage and the capsule fills the header band, no slivers peek around it. */
private const val CONV_CAPSULE_GROW_DP = 8f

/** Resting clearance from the chrome; clipToPadding = false still lets rows scroll into the band. */
private const val CONV_CHROME_GAP_DP = 6f

/** Header capsule to pinned strip: a divider, not a margin. The two read as one stack of pills. */
private const val CONV_BANNER_GAP_DP = 3f

/** Negative bottom margin grows the coordinator to y=0; translationZ is not optional, messages would paint over the toolbar. */
internal fun floatConvToolbar(holder: ViewGroup) {
    if (holder.getTag(convFloatTag) != null) return
    holder.addOnLayoutChangeListener(object : View.OnLayoutChangeListener {
        override fun onLayoutChange(
            v: View, l: Int, t: Int, r: Int, b: Int, ol: Int, ot: Int, or_: Int, ob: Int,
        ) {
            val h = b - t
            val lp = v.layoutParams as? ViewGroup.MarginLayoutParams ?: return
            if (h <= 0 || lp.bottomMargin < 0) return          // already floated
            v.removeOnLayoutChangeListener(this)
            v.setTag(convFloatTag, true)
            lp.bottomMargin = -h
            v.layoutParams = lp
            if (v.translationZ < 1f) v.translationZ = 1f
            XposedBridge.log("[$TAG] conversation toolbar floated (h=$h, bottomMargin=-$h)")
            // The banner may have attached before the height existed; its offset derives from it.
            convBannerRef?.get()?.let { b -> runCatching { syncConvBanner(b) } }
            runCatching { syncConvToolbar() }
        }
    })
    holder.requestLayout()
}

/** The banner shares the coordinator's top edge with the floated toolbar, so without this it is never visible. */
internal fun clearConvBanner(banner: ViewGroup) {
    convBannerRef = WeakReference(banner)
    syncConvBanner(banner)
    if (banner.getTag(convBannerTag) != null) return
    banner.setTag(convBannerTag, true)
    // Height is 0 until something is pinned, so the offset has to be re-derived rather than set once.
    banner.addOnLayoutChangeListener { v, _, _, _, _, _, _, _, _ ->
        (v as? ViewGroup)?.let { runCatching { syncConvBanner(it) } }
    }
}

/** Offsets the strip below the header capsule, and takes it back when the strip empties. */
private fun syncConvBanner(banner: ViewGroup) {
    val lp = banner.layoutParams as? ViewGroup.MarginLayoutParams ?: return
    val gap = (CONV_BANNER_GAP_DP * banner.resources.displayMetrics.density).toInt()
    // Off the capsule's own bottom edge, not the holder's: the strip tracks the capsule even where the two differ.
    val below = if (convCapsuleBottom > 0) convCapsuleBottom + gap else (convHolderRef?.get()?.height ?: 0)
    // An empty strip must keep a zero margin or it opens a gap above the first message.
    val want = if (banner.height <= 0) 0 else below
    syncConvBannerPill(banner)
    if (lp.topMargin == want) return
    lp.topMargin = want
    banner.layoutParams = lp
    XposedBridge.log("[$TAG] conversation banner cleared of the toolbar (topMargin=$want)")
}

/** Same inset and stadium as the header capsule, so the strip reads as the next pill down, not a slab. */
private fun syncConvBannerPill(banner: ViewGroup) {
    if (banner.width <= 0 || banner.height <= 0) return
    val strip = (0 until banner.childCount)
        .mapNotNull { banner.getChildAt(it) as? ViewGroup }
        .firstOrNull { it !is GlassView } ?: return
    // WhatsApp's own opaque fill has to go, or the pane sits behind a slab and nothing of it shows.
    clearBg(strip, "conversation pinned strip")
    for (i in 0 until strip.childCount) {
        (strip.getChildAt(i) as? ViewGroup)?.let { clearBg(it, "conversation pinned strip inner") }
    }
    // Two levels down the strip ends in a plain hairline View, WhatsApp's divider; it would rule across the pill's bottom edge.
    val hairline = (4f * banner.resources.displayMetrics.density).toInt()
    clearHairlines(strip, strip.width / 2, hairline, depth = 3)
    val inset = (CONV_PILL_INSET_DP * banner.resources.displayMetrics.density).toInt()
    val r = banner.width - inset
    if (r - inset <= 0) return
    // The list host, never the coordinator (the strip is its child), and no fallback: a refused ancestor never re-points.
    pill(banner, strip, inset, 0, r, banner.height, source = convListHostRef?.get(), coordinatorFallback = false)
}

/** Plain Views at most [maxH] tall and at least [minW] wide, anywhere under [root] to [depth]; dividers carry no id. */
private fun clearHairlines(root: ViewGroup, minW: Int, maxH: Int, depth: Int) {
    for (i in 0 until root.childCount) {
        val c = root.getChildAt(i)
        if (c is ViewGroup) {
            if (depth > 1) clearHairlines(c, minW, maxH, depth - 1)
        } else if (c.height in 1..maxH && c.width >= minW) {
            clearBg(c, "conversation pinned strip divider")
        }
    }
}

/** RelativeLayout here, so the negative margin goes on the list host; the footer draws later and needs no translationZ. */
internal fun floatConvFooter(footer: ViewGroup) {
    if (footer.getTag(convFloatTag) != null) return
    val parent = footer.parent as? ViewGroup ?: return
    // Looked up in the listener: at attach every child still has height 0 and an early return would skip the float.
    footer.addOnLayoutChangeListener(object : View.OnLayoutChangeListener {
        override fun onLayoutChange(
            v: View, l: Int, t: Int, r: Int, b: Int, ol: Int, ot: Int, or_: Int, ob: Int,
        ) {
            val h = b - t
            if (h <= 0) return
            val listHost = convListHost(parent) ?: return
            val lp = listHost.layoutParams as? ViewGroup.MarginLayoutParams ?: return
            if (lp.bottomMargin < 0) return                    // already floated
            v.removeOnLayoutChangeListener(this)
            v.setTag(convFloatTag, true)
            // The list itself, before anything moves: its host never scrolls and would always read as at rest.
            val list = (0 until listHost.childCount)
                .mapNotNull { listHost.getChildAt(it) as? AbsListView }
                .firstOrNull()
            val before = list?.let { restOf(it) }
            lp.bottomMargin = -h
            listHost.layoutParams = lp
            val lift = liftConvFooter(v)
            XposedBridge.log(
                "[$TAG] conversation footer floated (h=$h, list host bottomMargin=-$h, lift=$lift)",
            )
            // The list keeps its clearance above the pill, which now sits higher.
            runCatching { padConvList(listHost, h + lift) }
            // Our margin and padding moved the content edge; a list resting on its last row is pinned there again, once.
            if (list != null && before != null) keepAtEnd(list, before)
            runCatching { syncConvFooter() }
        }
    })
    footer.requestLayout()
}

/** The row dissolve runs from the list's top edge to the pill's bottom plus this; bigger is gentler. */
private const val CONV_ROW_FADE_DP = 56f

private var convRowFadeLen = 0f

private var convBandRef: WeakReference<GlassView>? = null

/** The list's own parent, a plain FrameLayout: the pinned strip's backdrop and the row fade's reference edge. */
private var convListHostRef: WeakReference<ViewGroup>? = null

private fun convPillAlpha(): Int =
    if (convBandRef?.get()?.parent != null) {
        (TINT_ALPHA - convBandAlpha()).coerceAtLeast(0)
    } else {
        TINT_ALPHA
    }

/** Full-width band behind the toolbar pill, cut at its bottom. Wallpaper only: a backdrop would flicker as messages scroll under it. */
internal fun syncConvBand(holder: ViewGroup) {
    if (holder.height <= 0) return
    val under = wallpaperUnderlay(holder)
    // No wallpaper means nothing to transmit, and a tint-only band would just be a grey wash.
    if (under.isEmpty()) return
    val res = holder.resources
    val abrId = res.waId("action_bar_root", holder.context.packageName)
    if (abrId == 0) return
    val abr = holder.rootView?.findViewById<View>(abrId) as? FrameLayout ?: return

    // Solid to the pill's bottom, not the holder's.
    val at = IntArray(2)
    val abrAt = IntArray(2)
    holder.getLocationOnScreen(at)
    abr.getLocationOnScreen(abrAt)
    // The capsule's own number, set beside the rect it was given: read separately the two can disagree.
    val paneBottom = convPanes.values
        .mapNotNull { it.get() }
        .filter { it.parent === holder }
        .mapNotNull { it.layoutParams as? FrameLayout.LayoutParams }
        .maxOfOrNull { it.topMargin + it.height }
        ?: holder.height
    val pillBottom = if (convCapsuleBottom > 0) convCapsuleBottom else paneBottom
    if (paneBottom != pillBottom) {
        logOnce("conversation band: capsule says $pillBottom, the panes measure $paneBottom; the capsule wins")
    }
    val solid = (at[1] - abrAt[1]) + pillBottom
    if (solid <= 0) return
    // One pane, cut hard at the pill's bottom: abutting panes show their join, and the expanded SDF gives the cut no rim.
    var band = convBandRef?.get()
    if (band == null || band.parent !== abr) {
        band = GlassView(abr.context).apply {
            underlay = under
            params.apply {
                downsample = DOWNSAMPLE
                blurRadius = holder.dp(BLUR_DP)
                refractionEnabled = true
                // With the SDF expanded there is no bevel to size; a nominal hairline keeps depth and displacement at zero.
                bevelFraction = 0f
                bevelThickness = 1f
                depthRatio = DEPTH_RATIO
                maxDisplacePx = holder.dp(DISPLACE_DP)
                fresnelStrength = 0.5f
                cornerRadius = 0f
                // Full-bleed panel; a rim here would outline the screen.
                rimEnabled = false
                edgeExpandLeft = 8f
                edgeExpandTop = 8f
                edgeExpandRight = 8f
                edgeExpandBottom = 8f
            }
        }
        // Above the wallpaper and its dim; if they are not abr's children the band hides behind them, which is what the log is for.
        var insertAt = 0
        for (i in 0 until abr.childCount) {
            val c = abr.getChildAt(i)
            if (c === under.firstOrNull() || (under.size > 1 && c === under[1])) insertAt = i + 1
        }
        if (insertAt == 0) {
            XposedBridge.log(
                "[$TAG] WARN: wallpaper views are not children of action_bar_root; the band " +
                    "will be behind them and invisible",
            )
        }
        abr.addView(
            band, insertAt,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, solid).apply {
                gravity = Gravity.TOP
            },
        )
        convBandRef = WeakReference(band)
        XposedBridge.log(
            "[$TAG] conversation band inserted at index $insertAt " +
                "(solid=${solid}px tint=${convBandAlpha()})",
        )
    }
    band.params.tintColor = glassTint(convBandAlpha())
    val lp = band.layoutParams as? FrameLayout.LayoutParams ?: return
    if (lp.height != solid) {
        lp.height = solid
        band.layoutParams = lp
        XposedBridge.log("[$TAG] conversation band resized to ${solid}px (capsule bottom $pillBottom in the holder)")
    }
    convRowFadeLen = (solid - (convListHostRef?.get()?.let { h ->
        val a = IntArray(2); h.getLocationOnScreen(a); a[1]
    } ?: 0)) + holder.dp(CONV_ROW_FADE_DP)
    syncRowFade()
}

/** The framework's own fading edge; the ramp is also handed to the bubble background so bubble glass fades with the text. */
private fun syncRowFade() {
    val list = convListRef?.get() ?: return
    val len = convRowFadeLen
    if (len <= 0f) return
    if (!list.isVerticalFadingEdgeEnabled) {
        list.isVerticalFadingEdgeEnabled = true
        XposedBridge.log("[$TAG] row fade armed (${len.toInt()}px from the list's top edge)")
    }
    if (list.verticalFadingEdgeLength != len.toInt()) list.setFadingEdgeLength(len.toInt())
    val at = IntArray(2)
    list.getLocationOnScreen(at)
    convBubbleBgRef?.get()?.let { bg ->
        bg.fadeLineScreenY = at[1].toFloat()
        bg.fadeLen = len
    }
}

internal val pillPadTag = tagKey("wathemer-pill-pad")

private val mentionPaneTag = tagKey("wathemer-mention-pane")

private val mentionPreDrawTag = tagKey("wathemer-mention-predraw")

/** A wallpaper film under the mention list, and its painted fill goes; no source, because the conversation holds this pane. */
internal fun syncMentionPane(host: FrameLayout) {
    var pane = host.getTag(mentionPaneTag) as? GlassView
    if (pane == null || pane.parent !== host) {
        pane = GlassView(host.context).apply {
            underlay = wallpaperUnderlay(host)
            params.apply {
                downsample = DOWNSAMPLE
                blurRadius = host.dp(BLUR_DP)
                cornerRadius = host.dp(16f)
                refractionEnabled = true
                bevelFraction = BEVEL_FRACTION
                depthRatio = DEPTH_RATIO
                maxDisplacePx = host.dp(DISPLACE_DP)
                fresnelStrength = 0.5f
                tintColor = glassTint(convPillAlpha())
            }
        }
        host.addView(
            pane, 0,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT,
            ),
        )
        host.setTag(mentionPaneTag, pane)
        HookLog.hit("pane/mention")
    }
    // WhatsApp repaints the picker's fill per data pass with no layout to catch, so pre-draw it away.
    if (host.getTag(mentionPreDrawTag) == null) {
        host.setTag(mentionPreDrawTag, true)
        host.viewTreeObserver.addOnPreDrawListener {
            for (i in 0 until host.childCount) {
                val c = host.getChildAt(i)
                if (c !is GlassView && c.background != null) c.background = null
            }
            true
        }
    }
}

/** Zero every header pane but the one taking the capsule now, or two pills stack. */
private fun collapseHeaderPanes(holder: ViewGroup, keep: View) {
    val keepPane = convPanes[keep]?.get()
    // The holder's own children, never the weak map: an owner WhatsApp removes takes its pane's only handle with it.
    for (i in 0 until holder.childCount) {
        val g = holder.getChildAt(i) as? GlassView ?: continue
        if (g === keepPane) continue
        val glp = g.layoutParams ?: continue
        if (glp.width != 0 || glp.height != 0) {
            glp.width = 0
            glp.height = 0
            g.layoutParams = glp
        }
    }
}

/** One capsule spanning the toolbar, re-derived on every layout. */
internal fun syncConvToolbar() {
    val holder = convHolderRef?.get() ?: return
    if (holder.width <= 0 || holder.height <= 0) return
    // WhatsApp takes the toolbar out of this holder in search, so the search bar is looked up first.
    val barId = holder.resources.waId("search_view_toolbar", holder.context.packageName)
    val searchBar = (if (barId != 0) holder.findViewById<View>(barId) else null)
        ?.takeIf { it.isShown && it.width > 0 && it.height > 0 }
    if (searchBar != null) {
        collapseHeaderPanes(holder, searchBar)
        clearBg(searchBar, "conversation search bar")
        // The holder's own box, as the toolbar branch takes it, so search reads as the same header.
        val searchInset = (CONV_PILL_INSET_DP * holder.resources.displayMetrics.density).toInt()
        convCapsuleBottom = holder.height
        pill(holder, searchBar, searchInset, 0, holder.width - searchInset, holder.height)
        // Same pass, or the band keeps the bottom edge of whichever capsule it last saw.
        runCatching { syncConvBand(holder) }
        return
    }
    val toolbar = (0 until holder.childCount)
        .mapNotNull { holder.getChildAt(it) as? ViewGroup }
        .firstOrNull { it !is GlassView && it.javaClass.name.contains("Toolbar") } ?: return

    // In selection the bar lives in action_bar_root over this band; leave the capsule or that bar loses its pill.
    if (!toolbar.isShown) return
    collapseHeaderPanes(holder, toolbar)

    // WhatsApp's own bar fill has to go, or it covers the capsule and the wallpaper behind it.
    clearBg(toolbar, "conversation toolbar")
    // The foreground goes too, never a blanket kill; the divider is WDSToolbar.onDraw's, taken by ensureToolbarDividerHook via forcedBg.
    if (toolbar.foreground != null) {
        logOnce("conversation toolbar foreground cleared: ${toolbar.foreground?.javaClass?.name}")
        toolbar.foreground = null
    }

    val d = holder.resources.displayMetrics.density
    val inset = (CONV_PILL_INSET_DP * d).toInt()

    // Found structurally: the ActionMenuView has no id at all.
    var custom: ViewGroup? = null
    var actions: ViewGroup? = null
    for (i in 0 until toolbar.childCount) {
        val c = toolbar.getChildAt(i) as? ViewGroup ?: continue
        if (c.javaClass.name.contains("ActionMenuView")) actions = c
        else if (c.childCount > 0) custom = c
    }

    val backId = holder.resources.waId("whatsapp_toolbar_home", holder.context.packageName)
    val back = if (backId != 0) custom?.findViewById<View>(backId) else null

    // The band comes from the Back button, not the bar: the elements do not share a height.
    var refTop = -1
    var refBottom = -1
    if (back != null && back.width > 0) {
        rectInHolder(holder, back)
        refTop = convRect.top
        refBottom = convRect.bottom
    } else if (actions != null && actions.childCount > 0) {
        val a = actions.getChildAt(0)
        if (a != null && a.height > 0) {
            rectInHolder(holder, a)
            refTop = convRect.top
            refBottom = convRect.bottom
        }
    }
    if (refBottom <= refTop) return
    val trim = (CONV_PILL_TRIM_DP * d).toInt()
    // The holder clamp matters: clipChildren=true silently cuts an oversize capsule's rounded ends.
    val grow = (CONV_CAPSULE_GROW_DP * d).toInt()
    val pt = (refTop + trim / 2 - grow).coerceAtLeast(0)
    val pb = (refBottom - trim / 2 + grow).coerceAtMost(holder.height)
    val band = (pb - pt).coerceAtLeast(1)

    // ── One capsule ───────────────────────────────────────────────────────────────
    // WhatsApp's own layout spaces the controls inside it, so none of the per-pill centring defects can recur.
    val l = inset
    val r = holder.width - inset
    if (r - l > band) {
        convCapsuleBottom = pb
        pill(holder, toolbar, l, pt, r, pb)
        runCatching { syncConvBand(holder) }
    }
    convBannerRef?.get()?.let { b -> runCatching { syncConvBanner(b) } }
}

/** [convRect] = [child]'s bounds mapped into [holder]'s coordinates. */
private fun rectInHolder(holder: ViewGroup, child: View) {
    convRect.set(0, 0, child.width, child.height)
    holder.offsetDescendantRect(child, convRect)
}

/** Padding parks the messages clear of the chrome; clipToPadding = false lets them scroll behind it. */
private fun padConvList(listHost: ViewGroup, footerHeight: Int) {
    val list = (0 until listHost.childCount)
        .map { listHost.getChildAt(it) }
        .firstOrNull { it is AbsListView } as? AbsListView ?: return
    convListRef = WeakReference(list)
    convListHostRef = WeakReference(listHost)
    ensureRowHook()
    ensureBubbleBackground(list)
    // Beneath the list, whose own background carries the bubbles.
    ensureMsgSelectPane(listHost, list)
    val d = list.resources.displayMetrics.density
    val gap = (CONV_CHROME_GAP_DP * d).toInt()
    val holder = convHolderRef?.get()
    // Unchanged by the banner: the list host already starts below its height, and its margin stays under this padding.
    val top = (holder?.height ?: 0) + gap
    val bottom = footerHeight + gap
    if (list.paddingTop == top && list.paddingBottom == bottom) return
    list.clipToPadding = false
    list.setPadding(list.paddingLeft, top, list.paddingRight, bottom)
    XposedBridge.log("[$TAG] conversation list padded (top=$top bottom=$bottom)")
}

/** WhatsApp parks the scroll date on the list's padded top only when the list clips its padding, and this one does not. */
internal fun pinConvDate(date: View) {
    syncConvDate(date)
    if (date.getTag(convDateTag) != null) return
    date.setTag(convDateTag, true)
    // Each show and each new date lays the pill out, so this runs before it draws.
    date.addOnLayoutChangeListener { v, _, _, _, _, _, _, _, _ -> runCatching { syncConvDate(v) } }
}

/** Layout positions only: a measure that included the pill's own translation would chase itself. */
private fun syncConvDate(date: View) {
    val parent = date.parent as? ViewGroup ?: return
    val host = convListHost(parent) ?: return
    val list = (0 until host.childCount)
        .mapNotNull { host.getChildAt(it) as? AbsListView }
        .firstOrNull() ?: return
    // A clipping list gets WhatsApp's own setY, which this must not fight.
    if (list.clipToPadding) return
    val want = (host.top + list.top + list.paddingTop - date.top).toFloat()
    if (date.translationY != want) date.translationY = want
}

/** Where the list stood before a chrome change; the correction tells its own shift from a scroll made meanwhile. */
private class ListRest(val atEnd: Boolean, val first: Int, val count: Int)

/** Resting on the end means the last row is on screen and ends inside the content edge; an empty list never rests. */
private fun restOf(list: AbsListView): ListRest {
    val count = list.count
    val last = if (list.childCount > 0) list.getChildAt(list.childCount - 1) else null
    val atEnd = count > 0 && last != null && list.lastVisiblePosition == count - 1 &&
        last.bottom <= list.height - list.paddingBottom + 1
    return ListRest(atEnd, list.firstVisiblePosition, count)
}

/** One pre-draw after the change: pin the end again only if the list rested there and nothing else has moved it since. */
private fun keepAtEnd(list: AbsListView, before: ListRest) {
    if (!before.atEnd) return
    // Removed through the observer captured here; a detached view hands back a floating one.
    val observer = list.viewTreeObserver
    observer.addOnPreDrawListener(object : ViewTreeObserver.OnPreDrawListener {
        override fun onPreDraw(): Boolean {
            runCatching {
                if (observer.isAlive) observer.removeOnPreDrawListener(this)
                else list.viewTreeObserver.removeOnPreDrawListener(this)
            }
            // A different first row or count means WhatsApp placed the list itself; that placement stands.
            val untouched = list.isAttachedToWindow && list.count == before.count &&
                list.firstVisiblePosition == before.first
            if (!untouched || !list.canScrollVertically(1)) return true
            list.setSelection(list.count - 1)
            HookLog.hit("glass/conv/endPin")
            // The frame with the last row under the pill is never shown.
            return false
        }
    })
}

/** True when [v] sits in the conversation header, whose capsule already covers it; other paths stand down. */
internal fun convHeaderOwns(v: View): Boolean =
    convHolderRef?.get()?.let { isAncestorOf(it, v) } == true

/** The conversation's own AbsListView: the row hooks' identity test and the collectors' row source. */
internal var convListRef: WeakReference<ViewGroup>? = null

/** Found structurally, child 0 is a zero-height clipper; never derive from an index you did not set. */
internal fun convListHost(parent: ViewGroup): ViewGroup? {
    for (i in 0 until parent.childCount) {
        val c = parent.getChildAt(i) as? ViewGroup ?: continue
        if (c.height <= 0) continue
        if (containsList(c, 0)) return c
    }
    return null
}

private fun containsList(v: View, depth: Int): Boolean {
    if (v is AbsListView ||
        v is ViewGroup && v.javaClass.name.contains("ConversationListView")
    ) {
        return true
    }
    if (depth >= 3 || v !is ViewGroup) return false
    for (i in 0 until v.childCount) {
        if (containsList(v.getChildAt(i) ?: continue, depth + 1)) return true
    }
    return false
}

/** Keyed by the owner view: the toolbar, the search bar and the pinned strip each keep their own pane. */
internal fun pill(
    holder: ViewGroup, owner: View, l: Int, t: Int, r: Int, b: Int,
    source: View? = null, coordinatorFallback: Boolean = true,
) {
    if (r <= l || b <= t) return
    // A holder inside the coordinator has to name its own source, or the capture would contain the pane.
    val src = source ?: if (coordinatorFallback) convCoordRef?.get() else null
    var glass = convPanes[owner]?.get()
    if (glass == null || glass.parent !== holder) {
        glass = GlassView(holder.context).apply {
            backdrop = src
            underlay = wallpaperUnderlay(holder)
            params.apply {
                downsample = DOWNSAMPLE
                blurRadius = holder.dp(BLUR_DP)
                refractionEnabled = true
                bevelFraction = BEVEL_FRACTION
                depthRatio = DEPTH_RATIO
                maxDisplacePx = holder.dp(DISPLACE_DP)
                fresnelStrength = 0.5f
                tintColor = glassTint(convPillAlpha())
            }
        }
        holder.addView(glass, 0, FrameLayout.LayoutParams(0, 0))
        convPanes[owner] = WeakReference(glass)
        HookLog.hit("pane/convCapsule")
    } else if (glass.backdrop == null && src != null) {
        // The coordinator, or the banner's list host, may have attached after the pill did.
        glass.backdrop = src
    }
    // Re-asserted: the band may arrive after the pill, and the split depends on whether it exists.
    glass.params.tintColor = glassTint(convPillAlpha())
    val lp = glass.layoutParams as? FrameLayout.LayoutParams ?: return
    if (lp.width != r - l || lp.height != b - t || lp.leftMargin != l || lp.topMargin != t) {
        lp.width = r - l
        lp.height = b - t
        lp.leftMargin = l
        lp.topMargin = t
        lp.gravity = Gravity.TOP or Gravity.START
        glass.layoutParams = lp
        glass.params.cornerRadius = (b - t) / 2f
        // One log line per distinct rect, so an off-centre pill can be checked against numbers.
        val name = runCatching { owner.resources.getResourceEntryName(owner.id) }
            .getOrNull() ?: owner.javaClass.simpleName
        XposedBridge.log(
            "[$TAG] pill $name owner=${owner.left},${owner.top}-${owner.right},${owner.bottom} " +
                "pad(${owner.paddingLeft},${owner.paddingRight}) -> pane $l,$t-$r,$b",
        )
    }
}

/** Sized to input_layout so the send button keeps its own circle; backdrop is a sibling, so the capture cannot recurse. */
internal fun syncConvFooter() {
    val footer = convFooterRef?.get() ?: return
    if (footer.width <= 0 || footer.height <= 0) return
    if (footer.getTag(convFloatTag) != null) liftConvFooter(footer)
    // The selection card stands where the compose row was, and WhatsApp only hides the row, never removes it.
    if (convSelectionCardShown) {
        collapseConvPanes(footer)
        return
    }
    val res = footer.resources
    val pkg = footer.context.packageName
    val inputId = res.waId("input_layout", pkg)
    val sendId = res.waId("conversation_entry_action_button", pkg)
    // ── No compose row where you cannot compose ────────────────────────────────────
    // These replace the compose row while input_layout stays VISIBLE; collapse by size, which the next sizing pass undoes.
    for (n in listOf(
        "read_only_chat_info_container",
        "composer_blocker",
        "voice_note_draft_layout_v2",
    )) {
        val id = res.waId(n, pkg)
        if (id == 0) continue
        val v = footer.rootView?.findViewById<View>(id) ?: continue
        if (v.isShown) {
            val draft = n == "voice_note_draft_layout_v2"
            // The draft keeps its own pane: zeroing it here for composePane to re-size below is two writers a pass.
            collapseConvPanes(footer, keep = if (draft) v else null)
            // The recorder's stock card was neutralised with the shell; give it back, sized to the layout, the footer is taller.
            if (draft && v.width > 0 && v.height > 0) {
                convRect.set(0, 0, v.width, v.height)
                footer.offsetDescendantRect(v, convRect)
                composePane(
                    footer, v,
                    convRect.left, convRect.top, convRect.right, convRect.bottom,
                    (footer.parent as? ViewGroup)?.let { p -> convListHost(p) },
                )
            }
            return
        }
    }

    val input = if (inputId != 0) footer.findViewById<View>(inputId) else null
    val send = if (sendId != 0) footer.findViewById<View>(sendId) else null
    // Same lookup as floatConvFooter, and for the same reason: index 0 is a zero-height clipper.
    val listHost = (footer.parent as? ViewGroup)?.let { convListHost(it) }

    // An ancestor going gone leaves both owners VISIBLE at their last size, so neither is presence.
    if (goneAbove(input, footer) && goneAbove(send, footer)) {
        collapseConvPanes(footer)
        return
    }

    // Only owners this pass will not re-size: collapsing the live pair costs two layout passes per frame.
    if (convPanes.isNotEmpty()) {
        // parent === footer only: the header capsule shares this map and belongs to syncConvToolbar.
        val gone = ArrayList<View>()
        for ((owner, ref) in convPanes) {
            val glass = ref.get() ?: continue
            if (glass.parent !== footer) continue
            if (owner === input || owner === send) continue
            // Departed, not merely unmeasured: a live owner reads zero-size on animation frames.
            if (!owner.isAttachedToWindow || owner.parent == null) {
                gone.add(owner)
                continue
            }
            // Still attached, so a layout is coming and a zeroed size will actually apply.
            val lp = glass.layoutParams
            if (lp != null && (lp.width != 0 || lp.height != 0)) {
                lp.width = 0
                lp.height = 0
                glass.layoutParams = lp
            }
        }
        for (o in gone) {
            convPanes.remove(o)?.get()?.let { g -> (g.parent as? ViewGroup)?.removeView(g) }
        }
    }

    if (input != null && input.width > 0) {
        clearBg(input, "input_layout")
        // The mic disc's own screen margin; the pill's left edge mirrors it or the corner clips.
        var sideFloor = 0
        if (send != null && send.width > 0) {
            val sr = Rect(0, 0, send.width, send.height)
            if (footer.offsetDescendantRect(send, sr)) {
                sideFloor = (footer.width - sr.right).coerceAtLeast(0)
            }
        }
        convRect.set(0, 0, input.width, input.height)
        footer.offsetDescendantRect(input, convRect)
        // Grown so the icons can breathe, clamped because the footer is a ClippingLayout and shaves the overflow.
        val pad = footer.dp(COMPOSE_PILL_PAD_DP).toInt()
        composePane(
            footer, input,
            (convRect.left - pad).coerceAtLeast(sideFloor),
            (convRect.top - pad).coerceAtLeast(0),
            (convRect.right + pad).coerceAtMost(footer.width),
            (convRect.bottom + pad).coerceAtMost(footer.height),
            listHost,
        )
    }
    if (send != null && send.width > 0) {
        convRect.set(0, 0, send.width, send.height)
        footer.offsetDescendantRect(send, convRect)
        composePane(footer, send, convRect.left, convRect.top, convRect.right, convRect.bottom, listHost)
    }
}

/** The whole compose row rides one translation, so the pill, the send disc and their panes cannot separate. */
private fun liftConvFooter(footer: View): Int {
    val lift = footer.dp(COMPOSE_PILL_LIFT_DP)
    // Written only on a mismatch: this runs from a layout pass, and a transform write asks for a frame.
    if (footer.translationY != -lift) footer.translationY = -lift
    return lift.toInt()
}

/** GONE between an owner and the footer is the composer removed; INVISIBLE there is the open animation. */
private fun goneAbove(v: View?, stop: View): Boolean {
    var p: View? = v ?: return true
    var hops = 0
    while (p != null && hops < 8) {
        if (p.visibility == View.GONE) return true
        if (p === stop) return false
        p = p.parent as? View
        hops++
    }
    return false
}

/** Zero-size, never hide: composePane re-sizes a zeroed pane and nothing restores a hidden one; the map also holds the header capsule. */
private fun collapseConvPanes(footer: ViewGroup, keep: View? = null) {
    val keepPane = keep?.let { convPanes[it]?.get() }
    for (ref in convPanes.values) {
        val glass = ref.get() ?: continue
        if (glass.parent !== footer || glass === keepPane) continue
        val lp = glass.layoutParams ?: continue
        if (lp.width != 0 || lp.height != 0) {
            lp.width = 0
            lp.height = 0
            glass.layoutParams = lp
        }
    }
}

private fun composePane(
    footer: ViewGroup,
    owner: View,
    l: Int,
    t: Int,
    r: Int,
    b: Int,
    backdropView: ViewGroup?,
) {
    if (r <= l || b <= t) return
    var glass = convPanes[owner]?.get()
    if (glass == null || glass.parent !== footer) {
        glass = GlassView(footer.context).apply {
            backdrop = backdropView
            underlay = wallpaperUnderlay(footer)
            params.apply {
                downsample = DOWNSAMPLE
                blurRadius = footer.dp(BLUR_DP)
                refractionEnabled = true
                bevelFraction = BEVEL_FRACTION
                depthRatio = DEPTH_RATIO
                maxDisplacePx = footer.dp(DISPLACE_DP)
                fresnelStrength = 0.5f
                tintColor = glassTint(TINT_ALPHA)
            }
        }
        // Index 0, so WhatsApp's own icons and the text field keep painting on top of it.
        footer.addView(glass, 0, FrameLayout.LayoutParams(0, 0))
        convPanes[owner] = WeakReference(glass)
        HookLog.hit("pane/convCompose")
    } else if (glass.backdrop == null && backdropView != null) {
        glass.backdrop = backdropView
    }
    val lp = glass.layoutParams as? FrameLayout.LayoutParams ?: return
    if (lp.width != r - l || lp.height != b - t || lp.leftMargin != l || lp.topMargin != t) {
        lp.width = r - l
        lp.height = b - t
        lp.leftMargin = l
        lp.topMargin = t
        lp.gravity = Gravity.TOP or Gravity.START
        glass.layoutParams = lp
        // Capped: height/2 on a two-row compose box sweeps the corners across the quote's thumbnail.
        glass.params.cornerRadius = minOf((b - t) / 2f, footer.dp(COMPOSE_MAX_RADIUS_DP))
    }
}

/** How far the compose pill is grown past `input_layout` so its icons are not flush. */
private const val COMPOSE_PILL_PAD_DP = 5f

/** How far the compose row sits off the bottom edge, so the pill reads as floating rather than docked. */
private const val COMPOSE_PILL_LIFT_DP = 6f

/** Ceiling on the compose pill's corner radius: half the single-row height. */
private const val COMPOSE_MAX_RADIUS_DP = 24f
