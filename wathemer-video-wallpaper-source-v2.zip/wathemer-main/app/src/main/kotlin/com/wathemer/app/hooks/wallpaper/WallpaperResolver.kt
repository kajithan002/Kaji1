// Wallpaper resolver: direct path, then cached copy in filesDir, then MediaStore; first hit wins, null means skip.
// If the direct path stops being readable the cached copy is served; the cache extension follows the selected media type.
package com.wathemer.app.hooks.wallpaper

import android.content.ContentResolver
import android.content.Context
import android.content.SharedPreferences
import android.provider.MediaStore
import android.util.Log
import com.wathemer.app.settings.prefs.Prefs
import java.io.File
import java.io.FileOutputStream

object WallpaperResolver {

    private const val TAG = "WaThemer.WPResolver"
    private const val IMAGE_CACHE_FILENAME = "wt_wallpaper.png"
    private const val VIDEO_CACHE_FILENAME = "wt_wallpaper.mp4"

    fun resolve(context: Context, prefs: SharedPreferences): File? {
        val storedPath = prefs.getString(Prefs.KEY_WALLPAPER_PATH, null)
            ?.takeIf { it.isNotBlank() }
            ?: return null
        val isVideo = storedPath.endsWith(".mp4", ignoreCase = true)

        // Strategy 1: direct File.
        val direct = File(storedPath)
        if (direct.canRead()) {
            cacheIfStale(direct, context, isVideo)
            return direct
        }

        // Strategy 2: refresh the private copy from MediaStore when a newly selected asset has just been indexed.
        val cache = cacheFile(context, isVideo)
        val indexedCopy = copyViaMediaStore(context, storedPath, cache)
        if (indexedCopy != null) return indexedCopy

        // Strategy 3: last-known-good copy if MediaStore has not indexed the selected file yet.
        return cache.takeIf { it.canRead() }
    }

    private fun cacheFile(context: Context, isVideo: Boolean): File =
        File(context.filesDir, if (isVideo) VIDEO_CACHE_FILENAME else IMAGE_CACHE_FILENAME)

    /** Mtime-checked copy; no-op when the cache is at least as new and the same size. */
    private fun cacheIfStale(source: File, context: Context, isVideo: Boolean) {
        val cache = cacheFile(context, isVideo)
        try {
            if (cache.exists() &&
                cache.lastModified() >= source.lastModified() &&
                cache.length() == source.length()
            ) {
                return
            }
            source.inputStream().use { input ->
                FileOutputStream(cache).use { out -> input.copyTo(out) }
            }
            cache.setLastModified(source.lastModified())
        } catch (t: Throwable) {
            Log.w(TAG, "cacheIfStale failed: ${t.message}")
        }
    }

    /** Cross-UID route: MediaStore reads indexed image/video files even when WA cannot read the path. */
    private fun copyViaMediaStore(context: Context, absolutePath: String, dest: File): File? {
        val resolver: ContentResolver = context.contentResolver
        val isVideo = absolutePath.endsWith(".mp4", ignoreCase = true)
        val collection = if (isVideo) {
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        } else {
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        }
        val idColumn = if (isVideo) MediaStore.Video.Media._ID else MediaStore.Images.Media._ID
        val dataColumn = if (isVideo) MediaStore.Video.Media.DATA else MediaStore.Images.Media.DATA
        val projection = arrayOf(idColumn)
        val selection = "$dataColumn = ?"
        val args = arrayOf(absolutePath)
        return try {
            resolver.query(collection, projection, selection, args, null)?.use { cursor ->
                if (!cursor.moveToFirst()) return null
                val id = cursor.getLong(0)
                val uri = collection.buildUpon().appendPath(id.toString()).build()
                val stream = resolver.openInputStream(uri) ?: return null
                val part = File(dest.parentFile, "${dest.name}.part")
                stream.use { input ->
                    FileOutputStream(part).use { out -> input.copyTo(out) }
                }
                if (!part.canRead() || part.length() == 0L) {
                    part.delete()
                    return null
                }
                if (!part.renameTo(dest)) {
                    dest.delete()
                    if (!part.renameTo(dest)) {
                        part.delete()
                        return null
                    }
                }
                dest.takeIf { it.canRead() && it.length() > 0L }
            }
        } catch (t: Throwable) {
            Log.w(TAG, "copyViaMediaStore failed for $absolutePath: ${t.message}")
            null
        }
    }

}
