package com.wathemer.app.settings

import android.app.Activity
import android.app.Application
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.wathemer.app.settings.components.RestartBar
import com.wathemer.app.settings.nav.NavController
import com.wathemer.app.settings.nav.Screen
import com.wathemer.app.settings.nav.rememberNavController
import com.wathemer.app.settings.prefs.ChatWallpaperLibrary
import com.wathemer.app.settings.prefs.FontLibrary
import com.wathemer.app.settings.prefs.Prefs
import com.wathemer.app.settings.prefs.ServiceBridge
import com.wathemer.app.settings.preview.ThemeSnapshotHost
import com.wathemer.app.settings.screens.CategoryListScreen
import com.wathemer.app.settings.screens.ChatBubbleShapesScreen
import com.wathemer.app.settings.screens.ChatTickStylesScreen
import com.wathemer.app.settings.screens.ChatRequest
import com.wathemer.app.settings.screens.ChatScreen
import com.wathemer.app.settings.screens.ChatWallpapersScreen
import com.wathemer.app.settings.screens.ExtrasScreen
import com.wathemer.app.settings.screens.GlobalColorsScreen
import com.wathemer.app.settings.screens.GlobalColorsToolbarScreen
import com.wathemer.app.settings.screens.GlobalColorsUnreadScreen
import com.wathemer.app.settings.screens.HomescreenScreen
import com.wathemer.app.settings.screens.LiquidGlassScreen
import com.wathemer.app.settings.screens.StatusBarScreen
import com.wathemer.app.settings.screens.StoreScreen
import com.wathemer.app.settings.screens.ThemesScreen
import com.wathemer.app.settings.screens.UpdatesScreen
import com.wathemer.app.settings.screens.WallpaperScreen
import com.wathemer.app.settings.screens.pendingChatRequest
import com.wathemer.app.settings.screens.pendingThemeFile
import com.wathemer.app.store.StoreSession

/** Hosts the settings UI over an in-memory nav stack; system back pops until the root, then Android closes the activity. */
class MainActivity : ComponentActivity() {

    // Held only so onStop can re-snapshot; the UI keeps using the local below.
    private var openPrefs: Prefs? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        armCropInsetFix()
        // Wired before the store opens: the reconcile and the migrations below are writes WhatsApp has not seen either.
        PendingRestart.load(this)
        Prefs.onWrite = { PendingRestart.mark(applicationContext) }
        val prefs = Prefs.open(this, ServiceBridge.awaitPrefs())
        openPrefs = prefs
        // Before the reconcile: an update hands over through the snapshot, an uninstall leaves none to import.
        val carried = runCatching { prefs.importSnapshotIfEmpty() }
            .onFailure { Log.w("WaThemer.Prefs", "importSnapshotIfEmpty threw: $it") }
            .getOrNull()
        carried?.let {
            if (it.imported > 0) Log.i("WaThemer.Prefs", "carried over ${it.imported} settings from ${it.source}")
        }
        importWarn = carried?.warn == true
        // Reconcile before the UI reads anything: a store a prior install left behind must not leak into this one.
        prefs.reconcileFreshInstall()?.let { r ->
            if (r.deferred) {
                Log.i(
                    "WaThemer.Prefs",
                    "fresh-install check deferred: framework store not visible yet",
                )
            } else if (r.cleared > 0) {
                val msg = if (r.writeFailed) {
                    "Couldn't clear ${r.cleared} settings from a previous install (LSPosed didn't take the change)."
                } else {
                    "Cleared ${r.cleared} settings from the previous install."
                }
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                Log.i(
                    "WaThemer.Prefs",
                    "fresh install: cleared=${r.cleared} writeFailed=${r.writeFailed} " +
                        "backup=${r.backup}",
                )
            }
        }
        // Must run after the fresh-install clear: running it first would migrate values about to be deleted.
        runCatching { prefs.migrateRemovedBubbleStyle4() }
            .onSuccess { n ->
                if (n != null && n > 0) {
                    Log.i("WaThemer.Prefs", "bubble-style migration: rewrote $n side(s)")
                }
            }
            .onFailure { Log.w("WaThemer.Prefs", "bubble-style migration threw: $it") }
        runCatching { prefs.migrateCollidingTokens() }
            .onSuccess { n ->
                if (n > 0) Log.i("WaThemer.Prefs", "token-collision migration: dodged $n token(s)")
            }
            .onFailure { Log.w("WaThemer.Prefs", "token-collision migration threw: $it") }
        // Moves the pre-library Downloads font into the library; WhatsApp could never read it there.
        runCatching { FontLibrary.migrateLegacyDownloadsFont(this, prefs) }
            .onSuccess { e ->
                if (e != null) Log.i("WaThemer.Prefs", "legacy user font imported: ${e.name}")
            }
            .onFailure { Log.w("WaThemer.Prefs", "legacy font import threw: $it") }
        // Last, so the snapshot holds the reconciled and migrated state rather than what preceded it.
        runCatching { prefs.exportForMigration() }
            .onSuccess { n -> if (n != null) Log.i("WaThemer.Prefs", "migration snapshot: $n settings") }
        // Only a fresh Activity takes a hand-off: a recreation carries the same Intent and must not replay it.
        if (savedInstanceState == null) {
            takeChatRequest(intent)
            takeThemeFile(intent)
        }
        setContent {
            WaThemerTheme {
                ThemeSnapshotHost(prefs) {
                    val nav = rememberNavController()
                    BackHandler(enabled = nav.canPop()) { nav.pop() }
                    AppRoot(nav, prefs) { msg ->
                        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    /** Back from elsewhere: a store download the system cut off while the app was away picks up where it stopped. */
    override fun onResume() {
        super.onResume()
        StoreSession.resumePaused(this)
    }

    /** Edits made this session postdate the launch snapshot, and leaving for the installer lands here. */
    override fun onStop() {
        super.onStop()
        runCatching { openPrefs?.exportForMigration() }
    }

    /** A hand-off while this Activity is already on top; singleTop delivers it here instead of recreating. */
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        takeChatRequest(intent)
        takeThemeFile(intent)
    }

    /** A theme file opened from another app, taken once; the read grant lives only while this task does. */
    private fun takeThemeFile(intent: Intent?) {
        if (intent?.action != Intent.ACTION_VIEW) return
        val uri = intent.data ?: return
        // Recents replays the task's root Intent long after the sender's grant is gone.
        if (intent.flags and Intent.FLAG_ACTIVITY_LAUNCHED_FROM_HISTORY != 0) return
        setIntent(Intent(intent).setAction(Intent.ACTION_MAIN).setData(null))
        pendingThemeFile.value = uri
    }

    /** Reads and consumes the chat extras; aged out, or recents re-delivers a task root intent. */
    private fun takeChatRequest(intent: Intent?) {
        val jid = intent?.getStringExtra(ChatWallpaperLibrary.EXTRA_JID) ?: return
        val name = intent.getStringExtra(ChatWallpaperLibrary.EXTRA_NAME)
        val sentAt = intent.getLongExtra(ChatWallpaperLibrary.EXTRA_SENT_AT, 0L)
        intent.removeExtra(ChatWallpaperLibrary.EXTRA_JID)
        intent.removeExtra(ChatWallpaperLibrary.EXTRA_NAME)
        intent.removeExtra(ChatWallpaperLibrary.EXTRA_SENT_AT)
        setIntent(intent)
        if (jid.isBlank() || System.currentTimeMillis() - sentAt > ChatWallpaperLibrary.HANDOFF_MAX_AGE_MS) return
        pendingChatRequest.value = ChatRequest(jid, ChatWallpaperLibrary.sanitizeName(name, null, jid))
    }
}

private const val UCROP_ACTIVITY = "com.yalantis.ucrop.UCropActivity"
private var cropInsetFixArmed = false

/** Pads UCrop's content by the system-bar insets: enforced edge-to-edge buries its toolbar, and a fitsSystemWindows theme cannot fix that. */
private fun ComponentActivity.armCropInsetFix() {
    if (cropInsetFixArmed) return
    cropInsetFixArmed = true
    application.registerActivityLifecycleCallbacks(object : Application.ActivityLifecycleCallbacks {
        override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {
            if (activity.javaClass.name != UCROP_ACTIVITY) return
            val content = activity.findViewById<View>(android.R.id.content) ?: return
            ViewCompat.setOnApplyWindowInsetsListener(content) { v, insets ->
                val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
                v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
                insets
            }
            ViewCompat.requestApplyInsets(content)
        }

        override fun onActivityStarted(activity: Activity) = Unit
        override fun onActivityResumed(activity: Activity) = Unit
        override fun onActivityPaused(activity: Activity) = Unit
        override fun onActivityStopped(activity: Activity) = Unit
        override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) = Unit
        override fun onActivityDestroyed(activity: Activity) = Unit
    })
}

/** Read by AppRoot; set once at launch, before setContent, so no state plumbing is needed. */
private var importWarn = false

@Composable
private fun AppRoot(nav: NavController, prefs: Prefs, onMessage: (String) -> Unit) {
    val banner = !prefs.moduleStoreActive || importWarn
    // A hand-off from WhatsApp replaces the stack; landing on top of wherever the user last was leaves back walking through it.
    val pending by pendingChatRequest
    val restartPending by PendingRestart.pending
    LaunchedEffect(pending) {
        if (pending != null && nav.current != Screen.ChatWallpapers) {
            nav.replaceAll(listOf(Screen.CategoryList, Screen.Wallpaper, Screen.ChatWallpapers))
        }
    }
    val pendingTheme by pendingThemeFile
    LaunchedEffect(pendingTheme) {
        if (pendingTheme != null && nav.current != Screen.Themes) nav.replaceAll(listOf(Screen.CategoryList, Screen.Themes))
    }
    // Padded here, not on the banner: the screens' Scaffolds subtract an inset an ancestor took, so the banner clears the clock and the title follows it.
    Column(modifier = Modifier.fillMaxSize().then(if (banner) Modifier.statusBarsPadding() else Modifier)) {
        // Standing banner, never a toast: with the module inactive every control silently changes nothing.
        if (!prefs.moduleStoreActive) {
            Text(
                text = "WaThemer isn't active. Enable it in LSPosed with WhatsApp or WhatsApp Business in its scope, then reopen the app.",
                color = Color(0xFF1A1207),
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFFFFC46B))
                    .padding(horizontal = 14.dp, vertical = 8.dp),
            )
        }
        // The one case the store starts over: an update skipped the export build, or the snapshot could not be read or written.
        if (importWarn && prefs.moduleStoreActive) {
            Text(
                text = "Settings couldn't be carried over. If you came from 0.9.4 or later, reinstall that version, open it once, then update again.",
                color = Color(0xFF1A1207),
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFFFFC46B))
                    .padding(horizontal = 14.dp, vertical = 8.dp),
            )
        }
        // While the bar shows it owns the bottom inset, so the screens' Scaffolds must not pad for it too.
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .then(
                    if (restartPending) Modifier.consumeWindowInsets(WindowInsets.navigationBars.only(WindowInsetsSides.Bottom))
                    else Modifier,
                ),
        ) {
            ScreenSwitch(nav, prefs, onMessage)
        }
        RestartBar(onMessage = onMessage)
    }
}

@Composable
private fun ScreenSwitch(nav: NavController, prefs: Prefs, onMessage: (String) -> Unit) {
    when (nav.current) {
        Screen.CategoryList        -> CategoryListScreen(nav, prefs, onMessage)

        Screen.GlobalColors        -> GlobalColorsScreen(nav, prefs, onMessage)
        Screen.GlobalColorsUnread  -> GlobalColorsUnreadScreen(nav, prefs)
        Screen.GlobalColorsToolbar -> GlobalColorsToolbarScreen(nav, prefs)
        Screen.StatusBar           -> StatusBarScreen(nav, prefs)

        Screen.Wallpaper           -> WallpaperScreen(nav, prefs)
        Screen.LiquidGlass         -> LiquidGlassScreen(nav, prefs)
        Screen.ChatWallpapers      -> ChatWallpapersScreen(nav, prefs, onMessage)

        Screen.Homescreen          -> HomescreenScreen(nav, prefs)
        Screen.Chat                -> ChatScreen(nav, prefs)
        Screen.ChatBubbleShapes   -> ChatBubbleShapesScreen(nav, prefs)
        Screen.ChatTickStyles     -> ChatTickStylesScreen(nav, prefs)

        Screen.Extras              -> ExtrasScreen(nav, prefs, onMessage)
        Screen.Themes              -> ThemesScreen(nav, prefs, onMessage)
        Screen.ThemeStore          -> StoreScreen(nav, prefs, onMessage)
        Screen.Updates             -> UpdatesScreen(nav, prefs, onMessage)
    }
}

@Composable
private fun WaThemerTheme(content: @Composable () -> Unit) {
    // Settings-UI dressing is fixed Coral, separate from the user's WhatsApp tokens.
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFFC95548),
            background = Color(0xFF0A0A0A),
            surface = Color(0xFF141414),
            onPrimary = Color(0xFF0A0A0A),
            onBackground = Color(0xFFFFFFFF),
            onSurface = Color(0xFFFFFFFF),
        ),
        content = content,
    )
}
