// Saved themes: one .wathemer per slot in filesDir/themes, filed under a stamp, with the display name inside the file.
// There is no index. The directory is the list, so nothing can go stale against it.
package com.wathemer.app.settings.prefs

import android.content.Context
import android.net.Uri
import android.util.Log
import com.wathemer.app.BuildConfig
import com.wathemer.app.hooks.ColorSeeds
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream

object ThemeLibrary {

    private const val TAG = "WaThemer.Themes"
    private const val UNDO_FILE = "undo_theme.wathemer"
    private const val KEEP_SHARED = 5

    /** [stamp] is the filename, one past the highest slot present, so a new slot always sorts newest. Deleting the top one frees its number, which nothing keys on. */
    data class Slot(val file: File, val stamp: Int, val doc: ThemeDoc)

    /** [problems] are things worth telling the user about a theme that still applied. */
    sealed interface Outcome {
        data class Applied(val name: String, val problems: List<String>) : Outcome
        data class Failed(val reason: String) : Outcome
        data object NeedsStorageAccess : Outcome
    }

    sealed interface Import {
        data class Added(val slot: Slot, val problems: List<String>) : Import
        data class Failed(val reason: String) : Import
    }

    // One writer at a time: a store download finishing in the background must not meet a rename or a save.
    private val lock = Any()

    /** For these three a stored 0 is a real colour; every other key uses 0 to mean "not overridden". */
    private val ZERO_IS_A_COLOUR = setOf(Prefs.KEY_PRIMARY, Prefs.KEY_BACKGROUND, Prefs.KEY_TEXT)

    fun dir(context: Context): File = File(context.filesDir, "themes")

    /** Every readable slot, newest first. A file that will not parse is skipped rather than repaired. */
    fun list(context: Context): List<Slot> = dir(context).listFiles().orEmpty()
        .mapNotNull { f ->
            val stamp = stampOf(f) ?: return@mapNotNull null
            val doc = ThemeFile.peek(f) ?: return@mapNotNull null
            Slot(f, stamp, doc)
        }
        .sortedByDescending { it.stamp }

    /** Capture the store into a new slot. Null when the file could not be written. */
    fun saveCurrent(context: Context, prefs: Prefs, name: String): Slot? = synchronized(lock) { saveLocked(context, prefs, name) }

    private fun saveLocked(context: Context, prefs: Prefs, name: String): Slot? {
        val source = wallpaperSource(context, prefs)
        val doc = capture(prefs, ThemeFile.sanitizeName(name), source != null)
        val stamp = nextStamp(context)
        val dest = File(dir(context), "$stamp${ThemeFile.EXTENSION}")
        if (!writeTo(dest, doc, source, fontSource(context, prefs))) return null
        Log.i(TAG, "saved '${doc.name}' as ${dest.name} (${dest.length()} bytes)")
        return Slot(dest, stamp, doc)
    }

    /** Copy a picked file into the library once it parses. The archive is rebuilt, so only what this version understands is kept. */
    fun importFile(context: Context, uri: Uri): Import = importFrom(context, null) { context.contentResolver.openInputStream(uri) }

    /** Copy a theme into the library from [open]; [store] records the store entry it came from, and whatever a file claims is dropped. */
    fun importFrom(context: Context, store: ThemeStoreRef?, open: () -> InputStream?): Import = synchronized(lock) {
        importLocked(context, store, open)
    }

    private fun importLocked(context: Context, store: ThemeStoreRef?, open: () -> InputStream?): Import {
        val stage = File(context.cacheDir, "theme_import.png")
        val loaded = runCatching {
            open()?.let { ThemeFile.load(it, stage) }
        }.getOrNull() ?: run {
            stage.delete()
            return Import.Failed("Couldn't open that file.")
        }
        val ok = loaded as? ThemeFile.Load.Ok ?: run {
            stage.delete()
            return Import.Failed((loaded as ThemeFile.Load.Failed).reason)
        }
        val stamp = nextStamp(context)
        val dest = File(dir(context), "$stamp${ThemeFile.EXTENSION}")
        val doc = ok.doc.copy(store = store)
        val written = writeTo(dest, doc, ok.wallpaper, ok.font)
        stage.delete()
        ok.font?.delete()
        if (!written) return Import.Failed("Couldn't save that theme.")
        Log.i(TAG, "imported '${doc.name}' as ${dest.name}")
        return Import.Added(Slot(dest, stamp, doc), ok.problems)
    }

    /** Rename by rewriting the archive: the name travels inside the file, so renaming the file would not carry. */
    fun rename(context: Context, slot: Slot, name: String): Boolean = synchronized(lock) { renameLocked(context, slot, name) }

    private fun renameLocked(context: Context, slot: Slot, name: String): Boolean {
        val stage = File(context.cacheDir, "theme_rename.png")
        val loaded = runCatching { ThemeFile.load(slot.file.inputStream(), stage) }.getOrNull()
        val ok = loaded as? ThemeFile.Load.Ok ?: run { stage.delete(); return false }
        val part = File(slot.file.parentFile, "${slot.file.name}.part")
        val written = runCatching {
            FileOutputStream(part).use {
                ThemeFile.write(it, ok.doc.copy(name = ThemeFile.sanitizeName(name)), ok.wallpaper, ok.font)
            }
        }.getOrDefault(false)
        stage.delete()
        ok.font?.delete()
        if (!written) { part.delete(); return false }
        // Keep the original until the replacement is in place, or a failed rename loses the slot.
        val backup = File(slot.file.parentFile, "${slot.file.name}.bak")
        backup.delete()
        if (!slot.file.renameTo(backup)) { part.delete(); return false }
        if (!part.renameTo(slot.file)) { backup.renameTo(slot.file); part.delete(); return false }
        backup.delete()
        return true
    }

    fun delete(slot: Slot) {
        synchronized(lock) { slot.file.delete() }
    }

    /** The highest version saved of each store entry, by store id. */
    fun storeVersions(context: Context): Map<String, Int> =
        list(context).mapNotNull { it.doc.store }.groupBy { it.id }.mapValues { e -> e.value.maxOf { it.version } }

    /** Removes the saved copies of store entry [id] older than [version]; the newest stays. */
    fun removeOlder(context: Context, id: String, version: Int): Int = synchronized(lock) {
        val older = list(context).filter { it.doc.store?.id == id && it.doc.store.version < version }
        older.forEach { it.file.delete() }
        older.size
    }

    /** Puts back a slot a rename left aside, and clears half-written files; nothing else touches the library meanwhile. */
    fun recover(context: Context): Int = synchronized(lock) {
        var fixed = 0
        for (f in dir(context).listFiles().orEmpty()) {
            when {
                f.name.endsWith(".part") -> if (f.delete()) fixed++
                f.name.endsWith("${ThemeFile.EXTENSION}.bak") -> {
                    val original = File(f.parentFile, f.name.removeSuffix(".bak"))
                    if (original.exists()) f.delete() else f.renameTo(original)
                    fixed++
                }
            }
        }
        fixed
    }

    /** Copy a slot out to wherever the picker chose. */
    fun exportTo(slot: Slot, out: OutputStream): Boolean = runCatching {
        slot.file.inputStream().use { it.copyTo(out) }
    }.onFailure { Log.w(TAG, "export failed: $it") }.isSuccess

    /** A copy under a name a person would recognise; the slot itself is filed under a number. */
    fun stageForShare(context: Context, slot: Slot): File? = synchronized(lock) { shareLocked(context, slot) }

    private fun shareLocked(context: Context, slot: Slot): File? = runCatching {
        val shareDir = File(context.cacheDir, "share").apply { mkdirs() }
        // An app can read a shared file long after the sheet closes, so the last few stay, each in its own folder.
        shareDir.listFiles().orEmpty().sortedByDescending { it.lastModified() }
            .drop(KEEP_SHARED - 1).forEach { it.deleteRecursively() }
        val stamp = System.currentTimeMillis()
        val dir = generateSequence(stamp) { it + 1 }.map { File(shareDir, it.toString()) }.first { !it.exists() }
        dir.mkdirs()
        val dest = File(dir, ThemeFile.suggestedFileName(slot.doc.name))
        slot.file.inputStream().use { input -> FileOutputStream(dest).use { input.copyTo(it) } }
        dest
    }.getOrNull()

    // ── Undo ──────────────────────────────────────────────────────────────

    fun undoFile(context: Context): File = File(context.filesDir, UNDO_FILE)

    /** The theme that was in place before the last apply, or null when there is nothing to go back to. */
    fun undoable(context: Context): ThemeDoc? =
        undoFile(context).takeIf { it.canRead() }?.let { ThemeFile.peek(it) }

    fun clearUndo(context: Context) {
        synchronized(lock) { undoFile(context).delete() }
    }

    // ── Apply ─────────────────────────────────────────────────────────────

    /** Apply a theme file. No setting is written until the whole archive has been read and the wallpaper is on disk. */
    fun apply(context: Context, prefs: Prefs, file: File, keepUndo: Boolean): Outcome =
        synchronized(lock) { applyLocked(context, prefs, file, keepUndo) }

    private fun applyLocked(context: Context, prefs: Prefs, file: File, keepUndo: Boolean): Outcome {
        val stage = File(context.cacheDir, "theme_apply.png")
        val loaded = runCatching { ThemeFile.load(file.inputStream(), stage) }.getOrNull()
            ?: run { stage.delete(); return Outcome.Failed("Couldn't open that theme file.") }
        val ok = loaded as? ThemeFile.Load.Ok
            ?: return Outcome.Failed((loaded as ThemeFile.Load.Failed).reason)
        // The staged font is copied into the library or dropped; either way it never outlives this call.
        try {
            return applyLoaded(context, prefs, ok, keepUndo)
        } finally {
            ok.font?.delete()
        }
    }

    private fun applyLoaded(context: Context, prefs: Prefs, ok: ThemeFile.Load.Ok, keepUndo: Boolean): Outcome {
        val doc = ok.doc
        val image = ok.wallpaper
        // Asked before anything is touched: the public copy WhatsApp reads cannot be written without it.
        if (image != null && !WallpaperAsset.hasAllFilesAccess()) {
            image.delete()
            return Outcome.NeedsStorageAccess
        }
        val problems = ok.problems.toMutableList()

        if (keepUndo) {
            val source = wallpaperSource(context, prefs)
            val before = capture(prefs, "Before ${doc.name}", source != null)
            if (!writeTo(undoFile(context), before, source, fontSource(context, prefs))) {
                problems += "Couldn't back up your current look, so this can't be undone."
            }
        }

        // Bytes first, then the pref that points at them, or a failed copy leaves the store aimed at nothing.
        val wallpaperPath = image?.let { staged ->
            val dest = WallpaperAsset.persist(context) { staged.inputStream() }
            staged.delete()
            dest?.absolutePath
                ?: return Outcome.Failed("Couldn't save the theme's wallpaper. Storage may be full.")
        }

        val clear = ArrayList<String>()
        val values = HashMap<String, Any>()

        planInto(doc, prefs, wallpaperPath, clear, values, problems)

        doc.font?.let { f -> applyFont(context, prefs, f, ok.font, clear, values, problems) }

        if (!prefs.applyThemeWrite(clear, values)) {
            return Outcome.Failed("Couldn't save your settings (LSPosed didn't take the change).")
        }
        Log.i(TAG, "applied '${doc.name}': ${values.size} keys, ${problems.size} problem(s)")
        return Outcome.Applied(doc.name, problems.distinct())
    }

    /** What applying [doc] writes over [prefs]; files and fonts stay with the caller, so Apply and the preview share one plan. */
    private fun planInto(
        doc: ThemeDoc,
        prefs: Prefs,
        wallpaperPath: String?,
        clear: MutableList<String>,
        values: MutableMap<String, Any>,
        problems: MutableList<String>,
    ) {
        doc.colors?.let { colors ->
            // Clear then set in one commit: a colour the theme does not carry has to go, or two themes mix.
            clear += Prefs.THEME_COLOR_KEYS
            for ((key, argb) in colors) {
                values[key] = when (key) {
                    Prefs.KEY_PRIMARY -> ColorSeeds.dodgeCollision(argb, ColorSeeds.PRIMARY)
                    Prefs.KEY_BACKGROUND -> ColorSeeds.dodgeCollision(argb, ColorSeeds.BACKGROUND)
                    Prefs.KEY_TEXT -> ColorSeeds.dodgeCollision(argb, ColorSeeds.TEXT)
                    else -> argb
                }
            }
        }

        for ((key, on) in doc.flags) values[key] = on

        doc.bubbles?.let { b ->
            values[Prefs.BUBBLE_STYLE_INCOMING] = resolveShape(b.incoming, problems)
            values[Prefs.BUBBLE_STYLE_OUTGOING] = resolveShape(b.outgoing, problems)
        }
        // Stock is the absent key, so a theme without a style leaves the store as a fresh install has it.
        doc.ticks?.let { t ->
            val v = resolveTick(t.style, problems)
            if (v == 0) clear += Prefs.TICK_STYLE else values[Prefs.TICK_STYLE] = v
        }

        // Glass has nothing to refract without a live wallpaper, and the settings gate cannot see an import.
        val wallpaperLive = doc.wallpaper?.let { wallpaperPath != null && it.enabled }
            ?: (prefs.wallpaperEnabled && !prefs.wallpaperPath.isNullOrBlank())
        doc.wallpaper?.let { w ->
            if (wallpaperPath != null) values[Prefs.KEY_WALLPAPER_PATH] = wallpaperPath else clear += Prefs.KEY_WALLPAPER_PATH
            values[Prefs.KEY_WALLPAPER_ENABLED] = wallpaperLive
            values[Prefs.KEY_WALLPAPER_DIM] = w.dim
            values[Prefs.KEY_WALLPAPER_BLUR] = w.blur
        }
        // A theme that names the switch sets it; one from before themes carried it only loses glass with its wallpaper.
        val glassWas = prefs.glassEnabled
        val glassWanted = doc.glass?.enabled ?: glassWas
        val glassOn = glassWanted && wallpaperLive
        if (doc.glass?.enabled != null || glassOn != glassWas) values[Prefs.KEY_GLASS_ENABLED] = glassOn
        if (glassWas && !glassOn) {
            problems += if (glassWanted) "Liquid Glass turned off: no wallpaper."
            else "Liquid Glass turned off: this theme doesn't use it."
        } else if (glassWanted && !glassOn) {
            problems += "Liquid Glass stays off: this theme has no wallpaper."
        }

        // Tuning only; the switch is settled above.
        doc.glass?.let { g ->
            values[Prefs.KEY_GLASS_BLUR] = g.blur
            values[Prefs.KEY_GLASS_TINT] = g.tint
            values[Prefs.KEY_GLASS_DISPLACE] = g.displace
            values[Prefs.KEY_GLASS_BEVEL] = g.bevel
            values[Prefs.KEY_GLASS_RADIUS] = g.radius
            values[Prefs.KEY_GLASS_GAMMA] = g.gamma
            values[Prefs.KEY_GLASS_RIM] = g.rim
            values[Prefs.KEY_GLASS_RIM_WIDTH] = g.rimWidth
            values[Prefs.KEY_GLASS_RIM_ANGLE] = g.rimAngle
            values[Prefs.KEY_GLASS_BUBBLE_MERGE] = g.bubbleMerge
            values[Prefs.KEY_GLASS_SATURATION] = g.saturation
            values[Prefs.KEY_GLASS_HUED_TINT] = g.huedTint
            values[Prefs.KEY_GLASS_LINEAR_COPY] = g.linearCopy
            values[Prefs.KEY_GLASS_EDGE_SHADOW] = g.edgeShadow
            values[Prefs.KEY_GLASS_GLOW] = g.glow
            values[Prefs.KEY_GLASS_EDGE_CLARITY] = g.edgeClarity
            values[Prefs.KEY_GLASS_LIVE_CLARITY] = g.liveClarity
            values[Prefs.KEY_GLASS_NAV_DROPLET] = g.navDroplet
            values[Prefs.KEY_GLASS_ASSEMBLE] = g.assemble
            values[Prefs.KEY_GLASS_ONE_BLUR] = g.oneBlur
            values[Prefs.KEY_GLASS_SMALL_OPTICS] = g.smallOptics
            values[Prefs.KEY_GLASS_POPUP_MORPH] = g.popupMorph
            values[Prefs.KEY_GLASS_ROW_OPTICS] = g.rowOptics
            values[Prefs.KEY_GLASS_SHAPED_BUBBLES] = g.shapedBubbles
            values[Prefs.KEY_GLASS_STILL_SKIPS_SCROLL] = g.stillSkipsScroll
            values[Prefs.KEY_GLASS_MEDIA_VIEWER] = g.mediaViewer
            values[Prefs.KEY_GLASS_BRIGHT_CAP] = g.brightCap
            values[Prefs.KEY_GLASS_IMMERSIVE_NAV] = g.immersiveNav
        }
    }

    /** [prefs] as it would read after applying [doc], built in memory; nothing real is written and no restart is owed. */
    fun previewPrefs(prefs: Prefs, doc: ThemeDoc, wallpaperPath: String?): Prefs? {
        val clear = ArrayList<String>()
        val values = HashMap<String, Any>()
        planInto(doc, prefs, wallpaperPath, clear, values, mutableListOf())
        return prefs.previewWith(clear, values)
    }

    private fun applyFont(
        context: Context,
        prefs: Prefs,
        font: ThemeFont,
        file: File?,
        clear: MutableList<String>,
        values: MutableMap<String, Any>,
        problems: MutableList<String>,
    ) {
        when (font.kind) {
            ThemeFontKind.STOCK -> clear += Prefs.KEY_CUSTOM_FONT
            ThemeFontKind.BUILTIN ->
                if (hasBundledFont(context, font.id)) {
                    values[Prefs.KEY_CUSTOM_FONT] = font.id
                } else {
                    clear += Prefs.KEY_CUSTOM_FONT
                    problems += "Font \"${font.id}\" isn't in this version; using the system font."
                }
            ThemeFontKind.USER -> {
                // The theme's own file first; a theme from before fonts travelled can only match one already here.
                val match = file?.let { FontLibrary.importFrom(context, prefs, it, font.name.ifBlank { null })?.entry }
                    ?: FontLibrary.list(context, prefs).firstOrNull { it.name.equals(font.name, true) }
                if (match != null) {
                    values[Prefs.KEY_CUSTOM_FONT] = "user"
                    values[Prefs.KEY_FONT_USER_FILE] = match.file
                    values[Prefs.KEY_FONT_USER_NAME] = match.name
                    values[Prefs.KEY_FONT_USER_STAMP] = match.stamp
                } else {
                    clear += Prefs.KEY_CUSTOM_FONT
                    problems += if (file != null) "Couldn't read the theme's font; using the system font."
                    else "This theme uses \"${font.name}\" but doesn't include it. Add it in Extras > Fonts."
                }
            }
        }
    }

    // ── Capture ───────────────────────────────────────────────────────────

    /** Read the store into a theme. Only colours that are set travel: an unset global must not arm the substitution on someone else's phone. */
    fun capture(prefs: Prefs, name: String, hasWallpaper: Boolean): ThemeDoc {
        val colors = LinkedHashMap<String, Int>()
        for (key in Prefs.THEME_COLOR_KEYS) {
            if (!prefs.isSet(key)) continue
            val v = prefs.getOverride(key)
            if (v == 0 && key !in ZERO_IS_A_COLOUR) continue
            colors[key] = v
        }
        // Built from the key list rather than by hand, so a flag added there cannot be left out of an export.
        val flags = Prefs.THEME_FLAG_KEYS.associateWith { key ->
            when (key) {
                Prefs.KEY_IOS_ICON_PACK -> prefs.iosIconPack
                Prefs.KEY_CHATLIST_DIVIDER -> prefs.chatListDivider
                Prefs.KEY_EFFECT_SNOW -> prefs.effectSnow
                Prefs.KEY_SYSTEM_BARS_ENABLED -> prefs.systemBarsEnabled
                Prefs.KEY_SYSTEM_BAR_AUTO_ICONS -> prefs.systemBarAutoIcons
                Prefs.KEY_FONT_MAP_MONOSPACE -> prefs.fontMapMonospace
                else -> { Log.w(TAG, "capture: no reader for flag $key"); false }
            }
        }
        val choice = prefs.customFont
        val font = when {
            choice.isBlank() -> ThemeFont(ThemeFontKind.STOCK, "", "")
            choice == "user" -> ThemeFont(ThemeFontKind.USER, "", prefs.fontUserName)
            else -> ThemeFont(ThemeFontKind.BUILTIN, choice, "")
        }
        return ThemeDoc(
            name = name,
            createdAt = System.currentTimeMillis(),
            appVersion = BuildConfig.VERSION_NAME,
            colors = colors,
            wallpaper = ThemeWallpaper(
                hasImage = hasWallpaper,
                enabled = prefs.wallpaperEnabled,
                dim = prefs.wallpaperDim,
                blur = prefs.wallpaperBlur,
            ),
            bubbles = ThemeBubbles(
                incoming = BubbleStyles.assetPrefix(prefs.getOverride(Prefs.BUBBLE_STYLE_INCOMING)),
                outgoing = BubbleStyles.assetPrefix(prefs.getOverride(Prefs.BUBBLE_STYLE_OUTGOING)),
            ),
            ticks = ThemeTicks(style = TickStyles.assetPrefix(prefs.getOverride(Prefs.TICK_STYLE))),
            flags = flags,
            font = font,
            // The whole look travels, so an untouched slider exports its default and the switch its state.
            glass = ThemeGlass(
                blur = prefs.glassBlur,
                tint = prefs.glassTint,
                displace = prefs.glassDisplace,
                bevel = prefs.glassBevel,
                radius = prefs.glassRadius,
                gamma = prefs.glassGamma,
                rim = prefs.glassRim,
                rimWidth = prefs.glassRimWidth,
                rimAngle = prefs.glassRimAngle,
                bubbleMerge = prefs.glassBubbleMerge,
                saturation = prefs.glassSaturation,
                huedTint = prefs.glassHuedTint,
                linearCopy = prefs.glassLinearCopy,
                edgeShadow = prefs.glassEdgeShadow,
                glow = prefs.glassGlow,
                edgeClarity = prefs.glassEdgeClarity,
                liveClarity = prefs.glassLiveClarity,
                navDroplet = prefs.glassNavDroplet,
                assemble = prefs.glassAssemble,
                oneBlur = prefs.glassOneBlur,
                smallOptics = prefs.glassSmallOptics,
                popupMorph = prefs.glassPopupMorph,
                rowOptics = prefs.glassRowOptics,
                shapedBubbles = prefs.glassShapedBubbles,
                stillSkipsScroll = prefs.glassStillSkipsScroll,
                mediaViewer = prefs.glassMediaViewer,
                brightCap = prefs.glassBrightCap,
                immersiveNav = prefs.glassImmersiveNav,
                enabled = prefs.glassEnabled,
            ),
        )
    }

    // ── Helpers ───────────────────────────────────────────────────────────

    /** The bytes to put in an archive: the public copy WhatsApp reads, else the private master behind it. */
    private fun wallpaperSource(context: Context, prefs: Prefs): File? {
        val path = prefs.wallpaperPath?.takeIf { it.isNotBlank() } ?: return null
        File(path).takeIf { it.canRead() }?.let { return it }
        return WallpaperAsset.masterFile(context).takeIf { it.canRead() }
    }

    /** The selected imported font's file, which a theme carries inside it; null for stock or a bundled face. */
    private fun fontSource(context: Context, prefs: Prefs): File? {
        if (prefs.customFont != "user" || prefs.fontUserFile.isBlank()) return null
        // The name only: the pref is a file in the fonts dir, never a path.
        return File(FontLibrary.dir(context), File(prefs.fontUserFile).name).takeIf { it.canRead() }
    }

    /** Asset name back to the stored 1-based index; a name this version does not have falls back to stock and says so. */
    private fun resolveShape(asset: String?, problems: MutableList<String>): Int {
        if (asset.isNullOrBlank()) return 0
        val i = BubbleStyles.ALL.indexOfFirst { it.asset == asset }
        if (i < 0) {
            problems += "The theme's bubble shape isn't in this version; using stock."
            return 0
        }
        return i + 1
    }

    /** Asset prefix back to the stored value; a prefix this version lacks falls back to stock and says so. */
    private fun resolveTick(prefix: String?, problems: MutableList<String>): Int {
        if (prefix.isNullOrBlank()) return 0
        val v = TickStyles.styleOf(prefix)
        if (v == 0) problems += "The theme's tick style isn't in this version; using stock."
        return v
    }

    /** The same test FontSwap makes inside WhatsApp, so a theme cannot name a face the hook would fail to find. */
    private fun hasBundledFont(context: Context, id: String): Boolean {
        if (id.isBlank()) return false
        return context.resources.getIdentifier("${id}_regular", "font", context.packageName) != 0
    }

    /** Stage through a .part so a half-written slot is never left where the list will read it. */
    private fun writeTo(dest: File, doc: ThemeDoc, wallpaper: File?, font: File?): Boolean {
        dest.parentFile?.mkdirs()
        val part = File(dest.parentFile, "${dest.name}.part")
        val ok = runCatching { FileOutputStream(part).use { ThemeFile.write(it, doc, wallpaper, font) } }
            .getOrDefault(false)
        if (!ok) { part.delete(); return false }
        dest.delete()
        if (!part.renameTo(dest)) { part.delete(); return false }
        return true
    }

    private fun nextStamp(context: Context): Int =
        (dir(context).listFiles().orEmpty().mapNotNull { stampOf(it) }.maxOrNull() ?: 0) + 1

    private fun stampOf(f: File): Int? {
        if (!f.isFile || !f.name.endsWith(ThemeFile.EXTENSION)) return null
        return f.name.removeSuffix(ThemeFile.EXTENSION).toIntOrNull()
    }
}
