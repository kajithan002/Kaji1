package com.wathemer.app.hooks.wallpaper

import android.graphics.SurfaceTexture
import android.media.MediaPlayer
import android.util.Log
import android.view.Surface
import android.view.TextureView
import java.io.File

/**
 * One silent, looping MP4 player bound to a full-screen TextureView.
 * It deliberately does not retain the Activity or TextureView, so WallpaperImage can keep it in a WeakHashMap.
 */
internal class VideoWallpaperController(
    private val file: File,
) : TextureView.SurfaceTextureListener {

    private var player: MediaPlayer? = null
    private var surface: Surface? = null
    private var prepared = false
    private var wantsPlayback = true
    private var closed = false

    fun attach(view: TextureView) {
        view.surfaceTextureListener = this
        if (view.isAvailable) {
            view.surfaceTexture?.let { onSurfaceTextureAvailable(it, view.width, view.height) }
        }
    }

    fun resume() {
        wantsPlayback = true
        startIfReady()
    }

    fun pause() {
        wantsPlayback = false
        runCatching {
            if (player?.isPlaying == true) player?.pause()
        }.onFailure { Log.w(TAG, "pause failed: $it") }
    }

    fun release() {
        closed = true
        wantsPlayback = false
        releasePlayer()
    }

    override fun onSurfaceTextureAvailable(texture: SurfaceTexture, width: Int, height: Int) {
        if (closed || player != null) return
        val output = Surface(texture)
        val media = MediaPlayer()
        surface = output
        player = media
        prepared = false
        try {
            media.isLooping = true
            media.setVolume(0f, 0f)
            media.setDataSource(file.absolutePath)
            media.setSurface(output)
            media.setOnPreparedListener { ready ->
                if (closed || player !== ready) {
                    runCatching { ready.release() }
                    return@setOnPreparedListener
                }
                prepared = true
                startIfReady()
            }
            media.setOnErrorListener { failed, what, extra ->
                Log.e(TAG, "MediaPlayer error for ${file.name}: what=$what extra=$extra")
                if (player === failed) releasePlayer()
                true
            }
            media.prepareAsync()
        } catch (t: Throwable) {
            Log.e(TAG, "could not start ${file.name}", t)
            releasePlayer()
        }
    }

    override fun onSurfaceTextureSizeChanged(texture: SurfaceTexture, width: Int, height: Int) = Unit

    override fun onSurfaceTextureDestroyed(texture: SurfaceTexture): Boolean {
        releasePlayer()
        return true
    }

    override fun onSurfaceTextureUpdated(texture: SurfaceTexture) = Unit

    private fun startIfReady() {
        if (!wantsPlayback || !prepared) return
        runCatching {
            if (player?.isPlaying != true) player?.start()
        }.onFailure { Log.w(TAG, "start failed: $it") }
    }

    private fun releasePlayer() {
        prepared = false
        val oldPlayer = player
        player = null
        runCatching { oldPlayer?.setOnPreparedListener(null) }
        runCatching { oldPlayer?.setOnErrorListener(null) }
        runCatching { oldPlayer?.release() }
        val oldSurface = surface
        surface = null
        runCatching { oldSurface?.release() }
    }

    private companion object {
        const val TAG = "WaThemer.VideoWP"
    }
}
