// What every glass surface reads: the tuning values the sliders write, the shared tint, and the
// small primitives that name, log and measure. Package-visible on purpose, private to the module.
package com.wathemer.app.hooks.glass

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.ViewParent
import android.view.animation.Interpolator
import android.view.animation.PathInterpolator
import android.widget.AbsListView
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import com.wathemer.app.glass.BackdropCapture
import com.wathemer.app.glass.GlassParams
import com.wathemer.app.glass.GlassView
import com.wathemer.app.glass.WallpaperLook
import com.wathemer.app.hooks.HookLog
import com.wathemer.app.hooks.ModulePrefs
import com.wathemer.app.hooks.waId
import com.wathemer.app.settings.prefs.GlassDefaults
import com.wathemer.app.settings.prefs.Prefs
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedHelpers
import java.lang.ref.WeakReference
import java.util.Collections
import java.util.WeakHashMap

internal const val TAG = "WaThemerGlass"

// ── Tuning constants, all in dp ───────────────────────────────────────────────────
// dp not px so every density matches the tuning device; var because loadGlassPrefs() overwrites these at install.
internal var BLUR_DP = GlassDefaults.BLUR.toFloat()

internal const val DOWNSAMPLE = 4f

// The panes' shared tint. Overwritten from KEY_GLASS_TINT at install; do not tune here, move the slider.
internal var TINT_ALPHA = GlassDefaults.TINT

/** The tint carries a whisper of the wallpaper's dominant hue when set; off is the neutral grey. */
internal var HUED_TINT = GlassDefaults.HUED_TINT

/** Cap on the hued tint's chroma, as a fraction of full: a whisper, never a colour. */
internal const val HUE_CAP = 0.2f

/** The wallpaper copies are shrunk and blurred in linear light when set; off is the display-space path. */
internal var LINEAR_COPY = GlassDefaults.LINEAR_COPY

/** The copies follow the Backdrop blur slider; read at install like every glass value. */
internal var ONE_BLUR = GlassDefaults.ONE_BLUR

/** The small pills run the bubble program over the copy. */
internal var SMALL_OPTICS = GlassDefaults.SMALL_OPTICS

/** The selected chat row runs the bubble program over the selection copy. */
internal var ROW_OPTICS = GlassDefaults.ROW_OPTICS

/** The tab pages' cards run on under the floating nav, whose glass then shows the list beneath. */
internal var IMMERSIVE_NAV = GlassDefaults.IMMERSIVE_NAV

/** The glow threshold as a fraction of the brightest value the dim and the gamma leave, so bright wallpaper detail can always reach it. */
internal const val BLOOM_THRESHOLD_FRACTION = 0.5f

// ── One band width for every surface, as a fraction ───────────────────────────────
// A fraction of each surface's smaller side: one fixed dp band cannot fit both a small pill and the big card.
internal var BEVEL_FRACTION = GlassDefaults.BEVEL / 100f

internal const val DEPTH_RATIO = 1f

// Must stay above BLUR_DP: the blur runs after refraction, and a wider blur smears the bend back to frost.
internal var DISPLACE_DP = GlassDefaults.DISPLACE.toFloat()

// Rim stroke, drawn on Canvas over the light pass. 0 alpha is off and costs nothing.
internal var RIM_ALPHA = GlassDefaults.RIM

internal var RIM_WIDTH_DP = GlassDefaults.RIM_WIDTH.toFloat()

// ── The chat-list card ────────────────────────────────────────────────────────────
/** Every card's corner radius; CardOutline's clip must get the same value or content corners sit proud. */
internal var CARD_RADIUS_DP = GlassDefaults.RADIUS.toFloat()

/** Corner radius for the popup menu's glass, when the popup's own shape gives none. */
internal const val PANEL_ROW_RADIUS_DP = 14f

/** The hairline between menu options. Low enough to read as a seam, not as a rule. */
internal const val POPUP_DIVIDER_ALPHA = 28

// Matches the gap my_search_bar keeps below itself when it sits beside the list, so the card sits symmetrically.
internal const val CARD_GAP_DP = 8f

// Every card, tighter than the pill's own inset. The one width knob.
internal const val CARD_INSET_DP = 6f

// Breathing room between a card's border and the content inside it, applied equally on all four sides. The one knob for "too cluttered".
internal const val CARD_CONTENT_PAD_DP = 8f

// ── Filter chips ──────────────────────────────────────────────────────────────────
// Drawn on the card, so tint-only: these alphas stack on the card's own tint; see FrostDrawable's source parameter.
internal const val CHIP_ALPHA = 40           // resting

internal const val CHIP_ALPHA_SELECTED = 105 // any selected chip

internal const val CHIP_RIM_ALPHA = 70

/** The reply quote's own surface, in the compose pill and in a bubble: lighter than the glass, not a slab. */
internal const val QUOTE_ALPHA = 30

internal const val QUOTE_RADIUS_DP = 16f

/** Selection reads as a clearer backdrop, not more colour; the hue stays WhatsApp's own selection colour. */
internal const val ROW_SELECT_ALPHA = 62

internal const val ROW_SELECT_LIFT = 26

internal const val ROW_SELECT_RIM_ALPHA = 70

internal const val ROW_SELECT_INSET_X_DP = 8f

internal const val ROW_SELECT_INSET_Y_DP = 5f

internal const val ROW_SELECT_RADIUS_DP = 18f

/** Grows the pressed row a hair without escaping the card's own inset. */
internal const val ROW_SELECT_SCALE = 1.012f

/** Rounded from WhatsApp's own FAB corner. */
internal const val FAB_RADIUS_DP = 16f

/** Brighter than the card so the buttons read; the ratio to TINT_ALPHA is what matters, not the absolute. */
internal const val FAB_ALPHA = 32

/** The large title, sized by the iOS reference's letter width rather than its height, on purpose. */
internal const val TITLE_SP = 44f

/** One clear step above WhatsApp's own title size. */
internal const val TOOLBAR_TITLE_SP = 23f

/** Pane growth and toolbar padding work as a pair; horizontal only, vertical growth just clamps to the appbar. */
internal const val ALT_PANE_PAD_DP = 9f

/** How much smaller the round Back pill is than the trailing pane is tall. */
internal const val BACK_PILL_TRIM_PX = 4

/** A scale, not padding: padding shrinks an ImageView's drawable but not an ActionMenuItemView's compound one. */
internal const val ALT_ICON_SCALE = 0.78f

internal fun View.dp(v: Float) = v * resources.displayMetrics.density

// Guard only the listener registration, never the paint: a repaint must be idempotent and must always run.
// ── A raw hashCode() is not a legal tag key ────────────────────────────────────────────
// Every view tag goes through tagKey: a bare hashCode key can make setTag throw.
internal fun tagKey(name: String): Int = (name.hashCode() and 0x00FFFFFF) or 0x7F000000

/** Read once at install; values are baked into surfaces as built, so changes need a WhatsApp restart. */
internal fun loadGlassPrefs(): Boolean {
    var enabled = false
    runCatching {
        val p = ModulePrefs.open()
        p.reload()
        val k = Prefs
        enabled = p.getBoolean(k.KEY_GLASS_ENABLED, false)
        if (!enabled) return@runCatching
        BLUR_DP = p.getInt(k.KEY_GLASS_BLUR, GlassDefaults.BLUR).toFloat()
        TINT_ALPHA = p.getInt(k.KEY_GLASS_TINT, GlassDefaults.TINT)
        DISPLACE_DP = p.getInt(k.KEY_GLASS_DISPLACE, GlassDefaults.DISPLACE).toFloat()
        BEVEL_FRACTION = p.getInt(k.KEY_GLASS_BEVEL, GlassDefaults.BEVEL) / 100f
        CARD_RADIUS_DP = p.getInt(k.KEY_GLASS_RADIUS, GlassDefaults.RADIUS).toFloat()
        RIM_ALPHA = p.getInt(k.KEY_GLASS_RIM, GlassDefaults.RIM)
        RIM_WIDTH_DP = p.getInt(k.KEY_GLASS_RIM_WIDTH, GlassDefaults.RIM_WIDTH).toFloat()
        // Set once here; every construction site would otherwise repeat them.
        GlassParams.defaultTransGamma = p.getInt(k.KEY_GLASS_GAMMA, GlassDefaults.GAMMA) / 100f
        GlassParams.defaultSaturation = p.getInt(k.KEY_GLASS_SATURATION, GlassDefaults.SATURATION).coerceIn(100, 200) / 100f
        GlassParams.defaultEdgeShadow = p.getInt(k.KEY_GLASS_EDGE_SHADOW, GlassDefaults.EDGE_SHADOW).coerceIn(0, 30) / 100f
        GlassParams.defaultBloom = p.getInt(k.KEY_GLASS_GLOW, GlassDefaults.GLOW).coerceIn(0, 100) / 100f
        GlassParams.defaultBrightCap = p.getInt(k.KEY_GLASS_BRIGHT_CAP, GlassDefaults.BRIGHT_CAP).coerceIn(0, 100) / 100f
        HUED_TINT = p.getBoolean(k.KEY_GLASS_HUED_TINT, GlassDefaults.HUED_TINT)
        LINEAR_COPY = p.getBoolean(k.KEY_GLASS_LINEAR_COPY, GlassDefaults.LINEAR_COPY)
        ONE_BLUR = p.getBoolean(k.KEY_GLASS_ONE_BLUR, GlassDefaults.ONE_BLUR)
        SMALL_OPTICS = p.getBoolean(k.KEY_GLASS_SMALL_OPTICS, GlassDefaults.SMALL_OPTICS)
        ROW_OPTICS = p.getBoolean(k.KEY_GLASS_ROW_OPTICS, GlassDefaults.ROW_OPTICS)
        IMMERSIVE_NAV = p.getBoolean(k.KEY_GLASS_IMMERSIVE_NAV, GlassDefaults.IMMERSIVE_NAV)
        GlassPopupMorph.enabled = p.getBoolean(k.KEY_GLASS_POPUP_MORPH, GlassDefaults.POPUP_MORPH)
        GlassParams.defaultDetail = p.getInt(k.KEY_GLASS_EDGE_CLARITY, GlassDefaults.EDGE_CLARITY).coerceIn(0, 100) / 100f
        BackdropCapture.liveRim = p.getBoolean(k.KEY_GLASS_LIVE_CLARITY, GlassDefaults.LIVE_CLARITY)
        GlassNavDroplet.enabled = p.getBoolean(k.KEY_GLASS_NAV_DROPLET, GlassDefaults.NAV_DROPLET)
        GlassView.assembleOnAppear = p.getBoolean(k.KEY_GLASS_ASSEMBLE, GlassDefaults.ASSEMBLE)
        GlassView.stillSkipsScroll = p.getBoolean(k.KEY_GLASS_STILL_SKIPS_SCROLL, GlassDefaults.STILL_SKIPS_SCROLL)
        MEDIA_VIEWER = p.getBoolean(k.KEY_GLASS_MEDIA_VIEWER, GlassDefaults.MEDIA_VIEWER)
        GlassParams.defaultRimStrokeAngle = p.getInt(k.KEY_GLASS_RIM_ANGLE, GlassDefaults.RIM_ANGLE).toFloat()
        // A set pill colour wins over the frost, the fabColored stand-down pattern.
        tokenTabPillSet = p.getInt(k.OVR_TAB_ACTIVE_PILL, 0) != 0
        navUnreadBg = p.getInt(k.KEY_UNREAD_ACCENT, 0)
        navUnreadText = p.getInt(k.KEY_UNREAD_COUNT_TEXT, 0)
        actionModeIconsColor = p.getInt(k.OVR_ACTION_MODE_ICONS, 0)
    }.onFailure { XposedBridge.log("[$TAG] glass prefs unreadable: $it") }
    return enabled
}

/** The user's action-mode icon colour, 0 when unset; the selection bar's close glyph takes it over white. */
internal var actionModeIconsColor = 0

/** Read at install: a set pill colour keeps the stock/user pill and the frost never registers. */
internal var tokenTabPillSet = false

/** The unread tokens win over the frost on the nav badge too; read at install like every glass value. */
internal var navUnreadBg = 0

internal var navUnreadText = 0

/** True once install completed; [badgeGlassFill] answers 0 before that. */
@Volatile internal var armed = false

private var selectorGuardArmed = false

/** The list selector is touch feedback, not backdrop: drawn into a pane's RenderNode its ripple arms an animator against that node, and the frame's own draw then dies on "Target already set!". */
internal fun ensureSelectorGuard() {
    if (selectorGuardArmed) return
    selectorGuardArmed = true
    runCatching {
        XposedHelpers.findAndHookMethod(
            AbsListView::class.java, "drawSelector", Canvas::class.java,
            object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    if (!BackdropCapture.capturing) return
                    param.result = null
                    logOnce("list selector held back while a pane was capturing")
                }
            },
        )
        HookLog.arm("guard/listSelector")
    }.onFailure { HookLog.fail("guard/listSelector", it) }
}

internal fun logOnce(msg: String) {
    if (loggedOnce.add(msg)) XposedBridge.log("[$TAG] $msg")
}

/** One-time log lines: the re-apply sites fire repeatedly per launch and bury the geometry lines. */
private val loggedOnce = Collections.synchronizedSet(HashSet<String>())

/** The tint's rgb from wallpaper luma, white over dark and black over bright, with the wallpaper's hue when asked; alpha is per surface. */
@Volatile private var glassTintRgb = 0xFFFFFF

// Volatile out of caution: the early resolve is posted to the main thread, and the draw path reads both without a lock.
@Volatile private var glassTintResolved = false

/** The shared pane tint: the resolved channel at the user's alpha. */
internal val glassTintColor: Int get() = glassTint(TINT_ALPHA)

/** The same tint at a different alpha, for surfaces that must read against the glass. */
internal fun glassTint(alpha: Int): Int =
    (alpha.coerceIn(0, 255) shl 24) or glassTintRgb

internal fun resolveGlassTint(views: List<View>) {
    if (glassTintResolved) return
    val image = views.firstOrNull() as? ImageView ?: return
    // Only the global wallpaper sets the channel; a chat's own image must not decide it for the whole process.
    val look = image.getTag(wallpaperLookTag) as? WallpaperLook
    if (look != null && !look.global) return
    val bmp = (image.drawable as? BitmapDrawable)?.bitmap ?: return
    val dim = (views.getOrNull(1)?.let { dimAlpha255(it) } ?: 0) / 255f
    resolveGlassTintFrom(bmp, dim)
}

/** The same resolve from a bitmap the cache decoded, before any window shows it. Needs a software bitmap. */
internal fun resolveGlassTintFrom(bmp: Bitmap, dim: Float) {
    if (glassTintResolved) return
    if (bmp.width <= 0 || bmp.height <= 0 || bmp.config == Bitmap.Config.HARDWARE) return
    glassTintResolved = true

    var sum = 0.0
    var n = 0
    var sx = 0.0
    var sy = 0.0
    val step = 16
    val hsv = FloatArray(3)
    for (iy in 0 until step) {
        for (ix in 0 until step) {
            val px = bmp.getPixel(
                (bmp.width - 1) * ix / (step - 1),
                (bmp.height - 1) * iy / (step - 1),
            )
            sum += 0.2126 * Color.red(px) + 0.7152 * Color.green(px) + 0.0722 * Color.blue(px)
            // Chroma-weighted hue vectors, in radians: grey pixels add nothing and opposed hues cancel toward grey.
            Color.colorToHSV(px, hsv)
            val c = (hsv[1] * hsv[2]).toDouble()
            val h = Math.toRadians(hsv[0].toDouble())
            sx += c * Math.cos(h)
            sy += c * Math.sin(h)
            n++
        }
    }
    val luma = (sum / n) * (1f - dim)

    // Crossfade the channel, not the alpha: 110..150 luma slides through grey instead of snapping.
    val t = ((luma - 110.0) / 40.0).coerceIn(0.0, 1.0)
    val ch = ((1.0 - t) * 255.0).toInt().coerceIn(0, 255)
    val chroma = (Math.hypot(sx, sy) / n).toFloat().coerceAtMost(HUE_CAP)
    // Wrapped into 0..360 before any HSV call, which treats a negative hue as red.
    val hue = ((Math.toDegrees(Math.atan2(sy, sx)) % 360.0 + 360.0) % 360.0).toFloat()
    if (HUED_TINT && chroma > 0f) {
        glassTintRgb = huedGrey(ch, hue, chroma)
        // The pane rim strokes are set at install as plain white; they take the same cast so no surface stands out.
        val rim = GlassParams.defaultRimStrokeColor
        GlassParams.defaultRimStrokeColor = (rim and 0xFF000000.toInt()) or huedGrey(255, hue, chroma)
    } else {
        glassTintRgb = ch * 0x010101
    }
    val top = Math.pow(1.0 - dim, 2.0 * GlassParams.defaultTransGamma)
    GlassParams.defaultBloomThreshold = (BLOOM_THRESHOLD_FRACTION * top).toFloat().coerceIn(0.01f, 1f)
    val rgbHex = "%06x".format(glassTintRgb)
    XposedBridge.log(
        "[$TAG] wallpaper luma=${luma.toInt()} (dim=$dim) hue=${hue.toInt()} chroma=$chroma " +
            "-> tint channel $ch rgb=$rgbHex hued=$HUED_TINT glowFrom=${GlassParams.defaultBloomThreshold} @ $TINT_ALPHA",
    )
}

/** Grey [level] pushed toward [hue] by [chroma] along a zero-luma direction, so the cast changes colour and never brightness. */
private fun huedGrey(level: Int, hue: Float, chroma: Float): Int {
    val pure = Color.HSVToColor(floatArrayOf(hue, 1f, 1f))
    val pr = Color.red(pure) / 255f
    val pg = Color.green(pure) / 255f
    val pb = Color.blue(pure) / 255f
    val pl = 0.2126f * pr + 0.7152f * pg + 0.0722f * pb
    fun ch(p: Float): Int = (level + chroma * 255f * (p - pl)).toInt().coerceIn(0, 255)
    return (ch(pr) shl 16) or (ch(pg) shl 8) or ch(pb)
}

internal val doneTag = tagKey("wathemer-glass-done")

internal val titleTag = tagKey("wathemer-glass-title")

internal val innerGlassTag = tagKey("wathemer-glass-inner")

internal val frostTag = tagKey("wathemer-frost")

internal var contentRef: WeakReference<ViewGroup>? = null

internal var headerRef: WeakReference<View>? = null

/** The `header` id, kept so a live header can be resolved rather than remembered. */
internal var homeHeaderId = 0

/** header's id, kept so a coordinator can ask whether it is the HOME one. Archived reuses the same layout. */
internal var headerIdPin = 0

/** The `toolbar` id, kept so the live one can be resolved rather than remembered. */
internal var homeToolbarId = 0

/** action_bar_root's id, pinned so the per-layout header checks read an int rather than ask by name. */
internal var actionBarRootId = 0

internal var toolbarRef: WeakReference<View>? = null

internal var navBarRef: WeakReference<View>? = null

internal var pagerHolderRef: WeakReference<View>? = null

/** bottom_nav_container: the nav pane's anchor, not its parent (a LinearLayout would displace the pane). */
internal var navHostRef: WeakReference<View>? = null

internal var navGlassRef: WeakReference<View>? = null

/** bottom_nav_container's id, kept so a card can ask whether the floating nav is in ITS window. */
internal var navContainerIdPin = 0

@Volatile internal var bottomInset = 0

/** [side, navHeight, lift], filled once the nav has been floated. */
@Volatile internal var navGeom: IntArray? = null

/** Backgrounds we insist on, keyed by INSTANCE: an id key fired mid-construction and crashed mutate(); the every-View hook must stay cheap. */
internal val forcedBg = WeakHashMap<View, Drawable>()

/** Names for [forcedBg]'s keys, for the log; a named view's setBackgroundColor is also forced transparent. */
internal val forcedBgLabels = WeakHashMap<View, String>()

// forceBg keeps re-asserting its drawable; never pair this with a background you set yourself, it will replace yours too.
/** A TRANSPARENT ColorDrawable, never null: Material reads its background back, and mutate() on null crashes WhatsApp. */
internal fun clearBg(v: View, what: String) {
    synchronized(forcedBgLabels) { forcedBgLabels[v] = what }
    val cur = synchronized(forcedBg) { forcedBg[v] }
    // Reuse this view's own transparent fill: a fresh one per layout is a real setBackground and its invalidate.
    if (cur is ColorDrawable && cur.color == Color.TRANSPARENT && v.background === cur) return
    forceBg(v, ColorDrawable(Color.TRANSPARENT), what)
}

internal fun forceBg(v: View, d: Drawable, what: String) {
    synchronized(forcedBgLabels) { forcedBgLabels[v] = what }
    val existing = synchronized(forcedBg) { forcedBg[v] }
    if (existing === d && v.background === d) return
    synchronized(forcedBg) { forcedBg[v] = d }
    v.background = d
    logOnce("background forced on $what")
}

/** Round by outline clip, never by swapping the background, which discards the user's tint and fights recolorBg. */
internal fun roundView(v: View, what: String) {
    v.outlineProvider = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            outline.setRoundRect(0, 0, view.width, view.height, view.height / 2f)
        }
    }
    v.clipToOutline = true
    v.invalidateOutline()
    XposedBridge.log("[$TAG] outline-clipped $what to a pill")
}

// Never add ConstraintLayout: an unconstrained index-0 child breaks the Broadcast page's + FAB.
/** True for containers that stack children: FrameLayout, or CoordinatorLayout matched by name to avoid the androidx dependency. */
internal fun canStack(vg: ViewGroup): Boolean =
    vg is FrameLayout || vg.javaClass.name.contains("CoordinatorLayout")

/** The Activity a view belongs to, through a capped walk of its ContextWrappers. */
internal fun activityOf(v: View): Activity? {
    var c: Context? = v.context
    var hops = 0
    while (c != null && hops < 8) {
        if (c is Activity) return c
        c = (c as? ContextWrapper)?.baseContext
        hops++
    }
    return null
}

/** True when [id] names an ancestor within [depth] hops; scopes generic ids to one host. */
internal fun insideId(v: View, id: Int, depth: Int): Boolean {
    var p: View? = v.parent as? View
    var hops = 0
    while (p != null && hops < depth) {
        if (p.id == id) return true
        p = p.parent as? View
        hops++
    }
    return false
}

/** Is [v] inside [maybeAncestor], itself included? Walks up at most 24 hops, so it costs depth, not subtree size. */
internal fun isAncestorOf(maybeAncestor: View, v: View): Boolean {
    var p: View? = v
    var hops = 0
    while (p != null && hops < 24) {
        if (p === maybeAncestor) return true
        p = p.parent as? View
        hops++
    }
    return false
}

/** offsetDescendantRectToMyCoords that never throws: some ROMs dump the whole view tree before throwing, and the frame stalls. */
internal fun ViewGroup.offsetDescendantRect(descendant: View, rect: Rect): Boolean {
    if (descendant !== this) {
        var p: ViewParent? = descendant.parent
        while (p is View && p !== this) p = p.parent
        if (p !== this) return false
    }
    return runCatching { offsetDescendantRectToMyCoords(descendant, rect) }.isSuccess
}

/** Corner radius of the background about to be replaced; must be called before that background is cleared. */
internal fun readCornerRadius(v: View): Float? {
    val d = v.background ?: return null
    (d as? GradientDrawable)?.let {
        val r = runCatching { it.cornerRadius }.getOrNull()
        if (r != null && r > 0f) return r
    }
    // Always null on current WhatsApp builds (R8 strips getCornerSize); do not start here when a radius is wrong.
    return runCatching {
        val model = XposedHelpers.callMethod(d, "getShapeAppearanceModel")
        val corner = XposedHelpers.callMethod(model, "getTopLeftCornerSize")
        val box = RectF(0f, 0f, v.width.toFloat(), v.height.toFloat())
        (XposedHelpers.callMethod(corner, "getCornerSize", box) as? Float)?.takeIf { it > 0f }
    }.getOrNull()
}

// ── Cross-fading the home content ──────────────────────────────────────────────────────
// pager_holder is hidden, never detached, so it can be faded; the cost is the compositing itself, not the buffer or duration.
internal const val SEARCH_FADE_MS = 200L

/** Material's standard easing: fast departure, long settle. Reads as weight. */
internal val searchInterp: Interpolator by lazy {
    PathInterpolator(0.2f, 0f, 0f, 1f)
}

/** Our injected wallpaper views, found by tag and re-resolved per pane; a recreation replaces them. */
internal fun wallpaperUnderlay(anyView: View): List<View> = runCatching {
    val root = anyView.rootView
    // Image first, then the dim, the order WallpaperImage adds them; literal tags avoid loading its class.
    listOfNotNull(
        root.findViewWithTag<View>("wt_wallpaper"),
        root.findViewWithTag<View>("wt_wallpaper_dim"),
    ).also { resolveGlassTint(it) }
}.getOrDefault(emptyList())

/** Home's wallpaper views, the last resort of [wallpaperUnderlayOf]. */
internal fun wallpaperUnderlayGlobal(): List<View> =
    contentRef?.get()?.let { wallpaperUnderlay(it) } ?: emptyList()

/** The wallpaper views of the Activity that owns [v]'s window; a sheet or popup root holds none, home's decor is the last resort. */
internal fun wallpaperUnderlayOf(v: View): List<View> {
    val own = wallpaperUnderlay(v)
    if (own.isNotEmpty()) return own
    val decor = activityOf(v)?.window?.decorView
    if (decor != null && decor !== v.rootView) {
        val viaActivity = wallpaperUnderlay(decor)
        if (viaActivity.isNotEmpty()) return viaActivity
    }
    return wallpaperUnderlayGlobal()
}

/** "Chats", localised, read off the bottom nav's first item. */
internal fun navLabel(): CharSequence? = navLabel(0)

/** Nav item [index]'s localised label; string resource names are stripped, and findViewById stops at the first match. */
internal fun navLabel(index: Int): CharSequence? = navLabels().getOrNull(index)

/** Every nav item's small label in tree order, which is tab order; one walk serves a whole sync pass. */
internal fun navLabels(): List<CharSequence> = runCatching {
    val nav = navBarRef?.get() ?: return emptyList()
    val id = nav.resources.waId("navigation_bar_item_small_label_view", nav.context.packageName)
    if (id == 0) return emptyList()
    val found = ArrayList<CharSequence>()
    fun walk(v: View) {
        if (v.id == id && v is TextView && v.text.isNotBlank()) found.add(v.text)
        if (v is ViewGroup) for (i in 0 until v.childCount) walk(v.getChildAt(i) ?: continue)
    }
    walk(nav)
    found
}.getOrDefault(emptyList())

/** The pager page [v] sits on, as its index: the page's left edge over the pager's width, since pages are laid out side by side. */
internal fun pageIndexOf(v: View): Int = runCatching {
    var child: View = v
    var parent = child.parent as? View
    var hops = 0
    while (parent != null && hops < 16) {
        if (isPager(parent)) {
            if (parent.width <= 0) return@runCatching -1
            return@runCatching Math.round(child.left.toFloat() / parent.width)
        }
        child = parent
        parent = child.parent as? View
        hops++
    }
    -1
}.getOrDefault(-1)

/** By class hierarchy name, never `is`: WhatsApp's pager is androidx's ViewPager from another classloader. */
private fun isPager(v: View): Boolean {
    var c: Class<*>? = v.javaClass
    while (c != null && c != Any::class.java) {
        if (c.name.contains("ViewPager")) return true
        c = c.superclass
    }
    return false
}

/** The nav label of the page [v] sits on, whatever tabs WhatsApp or a module put in the bar; null off the pager. */
internal fun navLabelForPage(v: View): CharSequence? {
    val index = pageIndexOf(v)
    return if (index < 0) null else navLabel(index)
}

internal fun primaryTextColor(ctx: Context): Int {
    val a = ctx.obtainStyledAttributes(intArrayOf(android.R.attr.textColorPrimary))
    val c = a.getColor(0, Color.WHITE)
    a.recycle()
    return c
}

/** The tints add where band and pill stack, so they split TINT_ALPHA: the sum must equal it exactly, including at 0. */
internal fun convBandAlpha(): Int = (TINT_ALPHA / 2).coerceAtLeast(0)

/** Inset of the conversation pills from the screen edges. */
internal const val CONV_PILL_INSET_DP = 6f

/** How far a header pane sits in from its bar; the search capsule and the folder capsule both use it. */
internal const val BAR_PANE_TRIM_DP = 4f

/** A user colour on either floating button stands glassFab down: a themeable surface belongs to the theme. */
internal var fabColored = false

internal var miniFabColored = false

/** Same stand-down as the FAB colours: glass must not stack under a colour the theme owns. */
internal var sendColored = false

/** White icons are only the fallback for unthemed-on-glass; a user's own icon colour must always win. */
internal var toolbarIconsColored = false

/** Has the user given the quote its own colour? Then [QuoteAndLabelColors] owns it, not us. */
internal var quoteColored = false

internal var sendIconColored = false
