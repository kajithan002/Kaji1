// Saved themes: keep what you have, share it, or take someone else's.
// The heavy file work runs off the main thread; a theme carrying a wallpaper is megabytes, not bytes.
package com.wathemer.app.settings.screens

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.text.format.DateFormat
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.wathemer.app.settings.components.CategoryRow
import com.wathemer.app.settings.components.ConfirmDialog
import com.wathemer.app.settings.components.DialogAction
import com.wathemer.app.settings.components.DialogDismiss
import com.wathemer.app.settings.components.NavTopBar
import com.wathemer.app.settings.components.NoticeDialog
import com.wathemer.app.settings.components.Palette
import com.wathemer.app.settings.components.SectionHeader
import com.wathemer.app.settings.components.NoteText
import com.wathemer.app.settings.components.ThemeDialog
import com.wathemer.app.settings.nav.NavController
import com.wathemer.app.settings.nav.Screen
import com.wathemer.app.settings.prefs.Prefs
import com.wathemer.app.settings.prefs.ThemeDoc
import com.wathemer.app.settings.prefs.ThemeFile
import com.wathemer.app.settings.prefs.ThemeLibrary
import com.wathemer.app.settings.preview.LocalThemeSnapshot
import com.wathemer.app.store.StoreConfig
import com.wathemer.app.store.StoreFiles
import java.util.Date
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private const val MAX_THEME_NAME = 48

/** Set by MainActivity from a VIEW Intent, taken once by Saved themes; process-level, like the chat hand-off. */
internal val pendingThemeFile = mutableStateOf<Uri?>(null)

/** The themes list, and everything you can do to one. A theme carries the whole look, glass and font included. */
@Composable
fun ThemesScreen(nav: NavController, prefs: Prefs, onMessage: (String) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snapshot = LocalThemeSnapshot.current

    var slots by remember { mutableStateOf<List<ThemeLibrary.Slot>>(emptyList()) }
    var undo by remember { mutableStateOf<ThemeDoc?>(null) }
    var latest by remember { mutableStateOf<Map<String, Int>>(emptyMap()) }
    var reload by remember { mutableIntStateOf(0) }
    var busy by remember { mutableStateOf(false) }

    var naming by remember { mutableStateOf(false) }
    var renaming by remember { mutableStateOf<ThemeLibrary.Slot?>(null) }
    var acting by remember { mutableStateOf<ThemeLibrary.Slot?>(null) }
    var applying by remember { mutableStateOf<ThemeLibrary.Slot?>(null) }
    var deleting by remember { mutableStateOf<ThemeLibrary.Slot?>(null) }
    var undoing by remember { mutableStateOf(false) }
    var notice by remember { mutableStateOf<List<String>>(emptyList()) }
    var exporting by remember { mutableStateOf<ThemeLibrary.Slot?>(null) }
    var submitting by remember { mutableStateOf<ThemeLibrary.Slot?>(null) }

    LaunchedEffect(reload) {
        val loaded = withContext(Dispatchers.IO) {
            Triple(
                ThemeLibrary.list(context),
                ThemeLibrary.undoable(context),
                // The summary the last store visit left; this screen never goes to the network.
                StoreFiles.readSummary(context, StoreConfig.TARGET.storeId)?.latest.orEmpty(),
            )
        }
        slots = loaded.first
        undo = loaded.second
        latest = loaded.third
    }

    fun newer(slot: ThemeLibrary.Slot): Boolean = slot.doc.store?.let { (latest[it.id] ?: 0) > it.version } ?: false

    // One gate for every file action: nothing overlaps, and the list is re-read when it is done.
    fun work(block: suspend () -> Unit) {
        // Dropping a tap silently is how a button comes to look broken; say why instead.
        if (busy) { onMessage("Still finishing the last one."); return }
        scope.launch {
            busy = true
            try { block() } finally { busy = false; reload++ }
        }
    }

    fun applyTheme(slot: ThemeLibrary.Slot, keepUndo: Boolean) = work {
        val report = applyThemeFile(context, prefs, snapshot, slot.file, keepUndo)
        onMessage(report.message)
        if (report.notes.isNotEmpty()) notice = report.notes
    }

    // One import for the picker and for a file opened from another app, so the two can never say different things.
    fun importUri(uri: Uri) = work {
        when (val result = withContext(Dispatchers.IO) { ThemeLibrary.importFile(context, uri) }) {
            is ThemeLibrary.Import.Added -> {
                onMessage("${result.slot.doc.name} added to your themes.")
                // Two dialogs at once reads as a mess; when there is something to say, say it and let them tap the row.
                if (result.problems.isNotEmpty()) notice = result.problems else applying = result.slot
            }
            is ThemeLibrary.Import.Failed -> onMessage(result.reason)
        }
    }

    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument(),
    ) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        importUri(uri)
    }

    // A file opened from another app waits while another action finishes, then takes the same road.
    LaunchedEffect(pendingThemeFile.value, busy) {
        val uri = pendingThemeFile.value ?: return@LaunchedEffect
        if (busy) return@LaunchedEffect
        pendingThemeFile.value = null
        importUri(uri)
    }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/octet-stream"),
    ) { uri ->
        val slot = exporting
        exporting = null
        if (uri == null) return@rememberLauncherForActivityResult
        // Lost if the activity was rebuilt behind the picker; say so rather than doing nothing.
        if (slot == null) {
            onMessage("Choose the theme again to save it.")
            return@rememberLauncherForActivityResult
        }
        work {
            val ok = withContext(Dispatchers.IO) {
                runCatching {
                    context.contentResolver.openOutputStream(uri)?.use { ThemeLibrary.exportTo(slot, it) } ?: false
                }.getOrDefault(false)
            }
            onMessage(if (ok) "${slot.doc.name} saved." else "Couldn't write that file.")
        }
    }

    fun share(slot: ThemeLibrary.Slot, toStore: Boolean) = work {
        val staged = withContext(Dispatchers.IO) { ThemeLibrary.stageForShare(context, slot) }
        val uri = staged?.let {
            runCatching { FileProvider.getUriForFile(context, "${context.packageName}.files", it) }.getOrNull()
        }
        if (uri == null) {
            onMessage("Couldn't share that theme.")
            return@work
        }
        val send = Intent(Intent.ACTION_SEND).apply {
            type = ThemeFile.MIME
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, if (toStore) "Theme submission: ${slot.doc.name}" else slot.doc.name)
            // The share sheet itself reads the file through clipData, and the grant stays explicit.
            clipData = ClipData.newRawUri(slot.doc.name, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        runCatching { context.startActivity(Intent.createChooser(send, if (toStore) "Send to the theme store" else "Share theme")) }
            .onFailure { onMessage("No app to share with.") }
    }

    Scaffold(containerColor = Palette.Bg) { inner ->
        Column(modifier = Modifier.fillMaxSize().padding(inner)) {
            NavTopBar(title = "Themes", onBack = { nav.pop() })
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(bottom = 12.dp),
            ) {
                CategoryRow(label = "Save the current look", onClick = { naming = true })
                CategoryRow(
                    label = "Open a theme file",
                    onClick = {
                        // Any type: most phones have no idea what a .wathemer file is, and a filter would hide it.
                        runCatching { importLauncher.launch(arrayOf("*/*")) }
                            .onFailure { onMessage("No file picker on this phone.") }
                    },
                )
                CategoryRow(
                    label = "Theme store",
                    divider = undo != null,
                    onClick = { nav.push(Screen.ThemeStore) },
                )
                undo?.let { doc ->
                    CategoryRow(
                        label = "Undo the last change",
                        description = whenText(context, doc.createdAt),
                        divider = false,
                        onClick = { undoing = true },
                    )
                }

                SectionHeader("Saved")
                if (slots.isEmpty()) {
                    NoteText(if (busy) "Working" else "Nothing saved yet.")
                } else {
                    slots.forEachIndexed { i, slot ->
                        ThemeSlotRow(context, slot, newer(slot), divider = i < slots.lastIndex) { acting = slot }
                    }
                }
            }
        }
    }

    if (naming) {
        NameDialog(
            title = "Name this theme",
            initial = "",
            confirmLabel = "Save",
            onConfirm = { name ->
                naming = false
                work {
                    val saved = withContext(Dispatchers.IO) { ThemeLibrary.saveCurrent(context, prefs, name) }
                    onMessage(if (saved != null) "Saved as ${saved.doc.name}." else "Couldn't save that theme.")
                }
            },
            onDismiss = { naming = false },
        )
    }

    renaming?.let { slot ->
        NameDialog(
            title = "Rename",
            initial = slot.doc.name,
            confirmLabel = "Rename",
            onConfirm = { name ->
                renaming = null
                work {
                    val ok = withContext(Dispatchers.IO) { ThemeLibrary.rename(context, slot, name) }
                    if (!ok) onMessage("Couldn't rename that theme.")
                }
            },
            onDismiss = { renaming = null },
        )
    }

    acting?.let { slot ->
        ActionsDialog(
            context = context,
            slot = slot,
            newer = newer(slot),
            onApply = { acting = null; applying = slot },
            onShare = { acting = null; share(slot, toStore = false) },
            onSubmit = { acting = null; submitting = slot },
            onExport = {
                acting = null
                exporting = slot
                runCatching { exportLauncher.launch(ThemeFile.suggestedFileName(slot.doc.name)) }
                    .onFailure { exporting = null; onMessage("No file picker on this phone.") }
            },
            onRename = { acting = null; renaming = slot },
            onDelete = { acting = null; deleting = slot },
            onDismiss = { acting = null },
        )
    }

    applying?.let { slot ->
        ConfirmDialog(
            title = "Apply ${slot.doc.name}?",
            body = applyBody(slot.doc),
            confirmLabel = "Apply",
            onConfirm = { applying = null; applyTheme(slot, keepUndo = true) },
            onDismiss = { applying = null },
        )
    }

    submitting?.let { slot ->
        ConfirmDialog(
            title = "Send to the theme store?",
            body = "Choose Telegram, then the @wathemer_chat group. Only send themes you made or are allowed to share.",
            confirmLabel = "Send",
            onConfirm = { submitting = null; share(slot, toStore = true) },
            onDismiss = { submitting = null },
        )
    }

    deleting?.let { slot ->
        ConfirmDialog(
            title = "Delete ${slot.doc.name}?",
            body = "",
            confirmLabel = "Delete",
            onConfirm = {
                deleting = null
                work { withContext(Dispatchers.IO) { ThemeLibrary.delete(slot) } }
            },
            onDismiss = { deleting = null },
        )
    }

    if (undoing) {
        val previous = undo
        ConfirmDialog(
            title = "Undo the last change?",
            body = "Goes back to before the last theme. Works once.",
            confirmLabel = "Undo",
            onConfirm = {
                undoing = false
                // Stamp 0 is a placeholder: the undo copy is not a slot, and apply only reads the file.
                if (previous != null) {
                    applyTheme(ThemeLibrary.Slot(ThemeLibrary.undoFile(context), 0, previous), keepUndo = false)
                }
            },
            onDismiss = { undoing = false },
        )
    }

    if (notice.isNotEmpty()) {
        NoticeDialog(notice) { notice = emptyList() }
    }
}

// ── Rows ─────────────────────────────────────────────────────────────────

@Composable
private fun ThemeSlotRow(context: Context, slot: ThemeLibrary.Slot, newer: Boolean, divider: Boolean, onClick: () -> Unit) {
    val doc = slot.doc
    CategoryRow(
        label = doc.name,
        description = describe(context, doc, newer),
        leading = {
            ThemeBadge(
                primary = doc.colors?.get(Prefs.KEY_PRIMARY) ?: Prefs.DEFAULT_PRIMARY,
                background = doc.colors?.get(Prefs.KEY_BACKGROUND) ?: Prefs.DEFAULT_BACKGROUND,
                text = doc.colors?.get(Prefs.KEY_TEXT) ?: Prefs.DEFAULT_TEXT,
            )
        },
        divider = divider,
        onClick = onClick,
    )
}

/** The three globals side by side. */
@Composable
private fun ThemeBadge(primary: Int, background: Int, text: Int) {
    Row(
        modifier = Modifier
            .border(1.dp, Palette.RuleStrong, RoundedCornerShape(6.dp))
            .padding(1.dp),
    ) {
        Box(Modifier.size(width = 8.dp, height = 22.dp).background(Color(primary), RoundedCornerShape(topStart = 5.dp, bottomStart = 5.dp)))
        Box(Modifier.size(width = 8.dp, height = 22.dp).background(Color(background)))
        Box(Modifier.size(width = 8.dp, height = 22.dp).background(Color(text), RoundedCornerShape(topEnd = 5.dp, bottomEnd = 5.dp)))
    }
}

// ── Dialogs ──────────────────────────────────────────────────────────────

@Composable
private fun ActionsDialog(
    context: Context,
    slot: ThemeLibrary.Slot,
    newer: Boolean,
    onApply: () -> Unit,
    onShare: () -> Unit,
    onSubmit: () -> Unit,
    onExport: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit,
    onDismiss: () -> Unit,
) {
    ThemeDialog(onDismiss) {
        Text(slot.doc.name, color = Palette.Fg, fontSize = 18.sp, fontWeight = FontWeight.Medium)
        Text(describe(context, slot.doc, newer), color = Palette.FgMuted, fontSize = 14.sp)
        // Body scrolls and the dismiss stays outside it, or a tall font scale pushes the last row off the window.
        Column(
            modifier = Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Button(onClick = onApply, modifier = Modifier.fillMaxWidth()) {
                Text("Apply", fontWeight = FontWeight.Medium)
            }
            DialogAction("Share", onShare)
            DialogAction("Send to the theme store", onSubmit)
            DialogAction("Save to a file", onExport)
            DialogAction("Rename", onRename)
            DialogAction("Delete", onDelete)
        }
        DialogDismiss("Close", onDismiss)
    }
}

@Composable
private fun NameDialog(
    title: String,
    initial: String,
    confirmLabel: String,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    var value by remember { mutableStateOf(initial) }
    ThemeDialog(onDismiss) {
        Text(title, color = Palette.Fg, fontSize = 18.sp, fontWeight = FontWeight.Medium)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Palette.RuleStrong, RoundedCornerShape(10.dp))
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            BasicTextField(
                value = value,
                // Filtered at the source: one line, capped at the length the theme format keeps.
                onValueChange = { raw -> value = raw.filterNot { it == '\n' || it == '\r' }.take(MAX_THEME_NAME) },
                modifier = Modifier.fillMaxWidth(),
                textStyle = TextStyle(color = Palette.Fg, fontSize = 16.sp),
                cursorBrush = SolidColor(Palette.Fg),
                singleLine = true,
                decorationBox = { innerField ->
                    Box {
                        if (value.isEmpty()) Text("My theme", color = Palette.FgSubtle, fontSize = 16.sp)
                        innerField()
                    }
                },
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            OutlinedButton(
                onClick = onDismiss,
                modifier = Modifier.weight(1f),
                border = BorderStroke(1.dp, Palette.RuleStrong),
            ) { Text("Cancel", color = Palette.Fg) }
            Button(
                onClick = { onConfirm(value.trim()) },
                enabled = value.isNotBlank(),
                modifier = Modifier.weight(1f),
            ) { Text(confirmLabel, fontWeight = FontWeight.Medium) }
        }
    }
}

// ── Text ─────────────────────────────────────────────────────────────────

/** One line under the name: where it came from, whether it carries a wallpaper, how many colours, and when it was made. */
private fun describe(context: Context, doc: ThemeDoc, newer: Boolean): String {
    val parts = mutableListOf<String>()
    if (doc.store != null) parts += if (newer) "Update available" else "From the store"
    if (doc.wallpaper?.hasImage == true) parts += "Wallpaper"
    when (val n = doc.colors?.size ?: 0) {
        0 -> parts += "Stock colours"
        1 -> parts += "1 colour"
        else -> parts += "$n colours"
    }
    if (doc.createdAt > 0L) parts += whenText(context, doc.createdAt)
    return parts.joinToString(" · ")
}

private fun whenText(context: Context, millis: Long): String =
    if (millis <= 0L) "earlier" else DateFormat.getMediumDateFormat(context).format(Date(millis))
