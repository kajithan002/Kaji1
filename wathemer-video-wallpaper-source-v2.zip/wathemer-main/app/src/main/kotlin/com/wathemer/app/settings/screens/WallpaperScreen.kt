// Custom wallpaper settings screen: enable toggle, gallery pick via UCrop to Downloads, dim, blur, preview.
// Turning the wallpaper off turns Liquid Glass off with it; glass has nothing to draw without one.
package com.wathemer.app.settings.screens

import android.app.Activity
import android.net.Uri
import android.util.Log
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Scaffold
import androidx.compose.material3.TextButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wathemer.app.hooks.wallpaper.BitmapDecoder
import com.wathemer.app.hooks.wallpaper.WallpaperImage
import com.wathemer.app.settings.components.CategoryRow
import com.wathemer.app.settings.components.NavTopBar
import com.wathemer.app.settings.components.Palette
import com.wathemer.app.settings.components.PreviewPanel
import com.wathemer.app.settings.components.SliderItem
import com.wathemer.app.settings.components.ToggleItem
import com.wathemer.app.settings.nav.NavController
import com.wathemer.app.settings.nav.Screen
import com.wathemer.app.settings.prefs.ChatWallpaperLibrary
import com.wathemer.app.settings.prefs.Prefs
import com.wathemer.app.settings.prefs.WallpaperAsset
import com.wathemer.app.settings.preview.LocalThemeSnapshot
import com.wathemer.app.settings.preview.previewBlurDp
import com.wathemer.app.settings.preview.updateWallpaperBlur
import com.wathemer.app.settings.preview.updateWallpaperDim
import com.wathemer.app.settings.preview.updateWallpaperEnabled
import com.wathemer.app.settings.preview.updateWallpaperPath
import com.yalantis.ucrop.UCrop
import java.io.File
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun WallpaperScreen(nav: NavController, prefs: Prefs) {
    val context = LocalContext.current
    val snapshot = LocalThemeSnapshot.current
    val snap by snapshot
    val scope = rememberCoroutineScope()
    val chatCount = ChatWallpaperLibrary.list(context, prefs).size
    var choosingMedia by remember { mutableStateOf(false) }

    // Self-repair once per entry; keyed on the path so a re-pick re-checks.
    LaunchedEffect(snap.wallpaperPath) {
        // The restore copy must run off main; the pref write after it must stay on main for Compose state.
        val hadGlass = prefs.glassEnabled
        val settled = withContext(Dispatchers.IO) { WallpaperAsset.reconcile(context, prefs) }
        if (settled != snap.wallpaperPath) snapshot.updateWallpaperPath(prefs, settled)
        // The prune takes glass with it, so say so here; the toggle below announces the same thing.
        if (hadGlass && !prefs.glassEnabled) {
            Toast.makeText(context, "Liquid Glass turned off too.", Toast.LENGTH_LONG).show()
        }
    }

    val cropLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult(),
    ) { result ->
        // Every failure gets a message; only RESULT_CANCELED stays silent, there silence is right.
        when {
            result.resultCode == Activity.RESULT_OK && result.data != null -> {
                val cropped = UCrop.getOutput(result.data!!)
                if (cropped == null) {
                    Log.w(LOGTAG, "crop returned OK with no output Uri")
                    Toast.makeText(context, "Couldn't read the cropped image.", Toast.LENGTH_LONG).show()
                } else scope.launch {
                    // Off main, the save copies the image twice; NonCancellable, or leaving the screen saves the file and skips the setting.
                    withContext(NonCancellable) {
                        val app = context.applicationContext
                        val dest = withContext(Dispatchers.IO) {
                            WallpaperAsset.persist(app) { app.contentResolver.openInputStream(cropped) }
                                .also { cropped.path?.let { p -> File(p).delete() } }
                        }
                        if (dest == null) {
                            Toast.makeText(app, "Couldn't save the wallpaper. Storage may be full.", Toast.LENGTH_LONG).show()
                        } else {
                            snapshot.updateWallpaperPath(prefs, dest.absolutePath)
                            if (!snapshot.value.wallpaperEnabled) snapshot.updateWallpaperEnabled(prefs, true)
                        }
                    }
                }
            }
            // UCrop shows nothing itself on failure; without this arm a bad image closes the crop screen unexplained.
            result.resultCode == UCrop.RESULT_ERROR -> {
                Log.w(LOGTAG, "crop failed: ${result.data?.let { UCrop.getError(it) }}")
                Toast.makeText(context, "Couldn't crop that image. Try another one.", Toast.LENGTH_LONG).show()
            }
        }
    }
    val pickLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent(),
    ) { uri: Uri? ->
        if (uri != null) {
            // Sweep leftover crops first: a pick that never came back left its temp behind.
            context.cacheDir.listFiles()?.forEach { if (it.name.startsWith("ucrop_wallpaper_")) it.delete() }
            val tempDest = File(context.cacheDir, "ucrop_wallpaper_${System.currentTimeMillis()}.png")
            val dm = context.resources.displayMetrics
            val cropIntent = UCrop.of(uri, Uri.fromFile(tempDest))
                .withAspectRatio(dm.widthPixels.toFloat(), dm.heightPixels.toFloat())
                .withMaxResultSize(dm.widthPixels, dm.heightPixels)
                .getIntent(context)
            cropLauncher.launch(cropIntent)
        }
    }

    val videoPickerLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent(),
    ) { uri: Uri? ->
        if (uri != null) scope.launch {
            withContext(NonCancellable) {
                val app = context.applicationContext
                val result = withContext(Dispatchers.IO) {
                    WallpaperAsset.persistVideo(app) { app.contentResolver.openInputStream(uri) }
                }
                when (result) {
                    is WallpaperAsset.VideoPersistResult.Saved -> {
                        snapshot.updateWallpaperPath(prefs, result.file.absolutePath)
                        if (!snapshot.value.wallpaperEnabled) snapshot.updateWallpaperEnabled(prefs, true)
                        if (prefs.glassEnabled) {
                            prefs.glassEnabled = false
                            Toast.makeText(app, "Liquid Glass was turned off for video wallpaper.", Toast.LENGTH_LONG).show()
                        }
                    }
                    WallpaperAsset.VideoPersistResult.Invalid ->
                        Toast.makeText(app, "Couldn't read that MP4 video.", Toast.LENGTH_LONG).show()
                    WallpaperAsset.VideoPersistResult.TooLarge ->
                        Toast.makeText(app, "Video too large (64 MB max).", Toast.LENGTH_LONG).show()
                    WallpaperAsset.VideoPersistResult.TooLong ->
                        Toast.makeText(app, "Video must be 30 seconds or shorter.", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    Scaffold(containerColor = Palette.Bg) { inner ->
        Column(modifier = Modifier.fillMaxSize().padding(inner)) {
            NavTopBar(title = "Wallpaper", onBack = { nav.pop() })
            PreviewPanel(modifier = Modifier.weight(0.4f).fillMaxWidth()) {
                WallpaperThumbnail(
                    path = snap.wallpaperPath,
                    stamp = snap.wallpaperStamp,
                    dim = snap.wallpaperDim,
                    blur = snap.wallpaperBlur,
                )
            }
            Column(
                modifier = Modifier
                    .weight(0.6f)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(bottom = 12.dp),
            ) {
                ToggleItem(
                    title = "Use wallpaper",
                    checked = snap.wallpaperEnabled,
                    onCheckedChange = { newChecked ->
                        snapshot.updateWallpaperEnabled(prefs, newChecked)
                        // The glass switch refuses to turn on without a wallpaper; this keeps that true the other way, never silently.
                        if (!newChecked && prefs.glassEnabled) {
                            prefs.glassEnabled = false
                            // Two lines max, Android truncates anything longer.
                            Toast.makeText(context, "Liquid Glass turned off too.", Toast.LENGTH_LONG).show()
                        }
                    },
                )
                CategoryRow(
                    label = if (snap.wallpaperPath.isNullOrBlank()) "Choose an image or video" else "Replace wallpaper",
                    onClick = {
                        if (!WallpaperAsset.hasAllFilesAccess()) {
                            WallpaperAsset.requestAllFilesAccess(context)
                        } else {
                            choosingMedia = true
                        }
                    },
                )
                SliderItem(
                    title = "Dim",
                    value = snap.wallpaperDim.toFloat(),
                    range = 0f..100f,
                    steps = 99,
                    onValueChange = { v -> snapshot.updateWallpaperDim(prefs, v.roundToInt()) },
                    valueLabel = { "${it.toInt()}%" },
                )
                // Range 0-150 must match Prefs.wallpaperBlur and WallpaperImage.
                SliderItem(
                    title = "Blur",
                    value = snap.wallpaperBlur.toFloat(),
                    range = 0f..150f,
                    steps = 149,
                    onValueChange = { v -> snapshot.updateWallpaperBlur(prefs, v.roundToInt()) },
                    valueLabel = { "${it.toInt()}" },
                )
                CategoryRow(
                    label = "Chat wallpapers",
                    trailingHint = if (chatCount == 0) "None" else "$chatCount",
                    divider = false,
                    onClick = { nav.push(Screen.ChatWallpapers) },
                )
            }
        }
    }

    if (choosingMedia) {
        AlertDialog(
            onDismissRequest = { choosingMedia = false },
            title = { Text("Choose wallpaper type", color = Palette.Fg) },
            text = {
                Column {
                    TextButton(
                        onClick = {
                            choosingMedia = false
                            pickLauncher.launch("image/*")
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Choose image", color = Palette.Fg) }
                    TextButton(
                        onClick = {
                            choosingMedia = false
                            videoPickerLauncher.launch("video/mp4")
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Choose video (MP4, up to 30 seconds)", color = Palette.Fg) }
                }
            },
            confirmButton = {
                TextButton(onClick = { choosingMedia = false }) {
                    Text("Cancel", color = Palette.Fg)
                }
            },
        )
    }
}

@Composable
private fun WallpaperThumbnail(path: String?, stamp: Long, dim: Int, blur: Int) {
    if (path.isNullOrBlank() || !File(path).canRead()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No wallpaper yet", color = Palette.FgMuted, fontSize = 14.sp)
        }
        return
    }
    // Keyed on the stamp too: the picker always writes the same file, so the path alone never changes.
    val bitmap = remember(path, stamp) {
        BitmapDecoder.decodePreview(File(path), 800, 800)
    }
    if (bitmap == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Couldn't load the wallpaper", color = Palette.FgMuted, fontSize = 14.sp)
        }
        return
    }
    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        // Shared with the chat previews (previewBlurDp) so the two cannot drift apart.
        val blurDp = previewBlurDp(blur, with(LocalDensity.current) { maxHeight.toPx() })

        val imageModifier = if (blurDp.value > 0.1f) {
            Modifier.fillMaxSize().blur(blurDp)
        } else {
            Modifier.fillMaxSize()
        }
        Image(
            bitmap = bitmap.asImageBitmap(),
            contentDescription = "Wallpaper preview",
            modifier = imageModifier,
            contentScale = ContentScale.Crop,
        )
        if (path.endsWith(".mp4", ignoreCase = true)) {
            Box(
                modifier = Modifier.align(Alignment.BottomEnd).padding(8.dp)
                    .background(Palette.Surface.copy(alpha = 0.85f), RoundedCornerShape(6.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp),
            ) {
                Text("VIDEO", color = Palette.Fg, fontSize = 11.sp)
            }
        }
        if (dim > 0) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(WallpaperImage.DIM_COLOR).copy(alpha = dim / 100f)),
            )
        }
    }
}

private const val LOGTAG = "WaThemer.Wallpaper"
