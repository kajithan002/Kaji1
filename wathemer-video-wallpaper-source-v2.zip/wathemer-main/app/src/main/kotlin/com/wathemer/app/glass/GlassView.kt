package com.wathemer.app.glass

import android.animation.ValueAnimator
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.RecordingCanvas
import android.graphics.RuntimeShader
import android.graphics.Shader
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.SystemClock
import android.util.AttributeSet
import android.util.Log
import android.view.View
import android.view.ViewOutlineProvider
import android.view.ViewTreeObserver
import android.widget.FrameLayout
import android.widget.ImageView
import java.lang.ref.WeakReference
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.sin

/** A pane of glass, a blurred and tinted copy of [backdrop] behind its own children: point it at a sibling drawn before it; on Tiramisu and up the refraction pass runs too. */
class GlassView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
) : FrameLayout(context, attrs, defStyleAttr) {

    val params = GlassParams(resources.displayMetrics.density)

    private val capture = BackdropCapture(this, params)

    /** The subtree to blur; an ancestor is refused per capture and the pane draws its underlay only. */
    var backdrop: View?
        get() = capture.source
        set(value) {
            capture.source = value
            // A source handed over later goes live at once, not a heartbeat late.
            if (stillSkipsScroll) lastActivityMs = SystemClock.uptimeMillis()
            invalidate()
        }

    /** Painted beneath [backdrop]; see [BackdropCapture.underlay]. */
    var underlay: List<View>
        get() = capture.underlay
        set(value) {
            capture.underlay = value
            if (stillSkipsScroll) lastActivityMs = SystemClock.uptimeMillis()
            invalidate()
        }

    /** Capture in pre-draw, and the capture-invalidate loop is deliberate: removing the invalidate freezes the glass, so throttle the idle case and never stop it. */
    private val preDrawListener = ViewTreeObserver.OnPreDrawListener {
        // Guarded whole: capture() draws WhatsApp's own views, and an escape here crashes the UI thread every frame.
        try {
            if (params.enabled && isAttachedToWindow) {
                val now = SystemClock.uptimeMillis()
                // A move is activity: a pane can move without resizing, and the capture is placed by position.
                getLocationOnScreen(screenLoc)
                if (screenLoc[0] != lastScreenX || screenLoc[1] != lastScreenY) {
                    lastScreenX = screenLoc[0]
                    lastScreenY = screenLoc[1]
                    lastActivityMs = now
                }
                if (sourceChanged?.invoke() == true) lastActivityMs = now
                // A pager keeps its neighbour pages attached; their panes show nothing, so they capture nothing.
                if (skipOffscreen && (screenLoc[0] >= resources.displayMetrics.widthPixels || screenLoc[0] + width <= 0)) {
                    return@OnPreDrawListener true
                }
                // Nothing live behind it: only the wallpaper views, or a dropped display list, change what it shows.
                if (stillSkipsScroll && backdrop == null) {
                    val fresh = capture.needsFreshCapture
                    val changed = underlayChanged()
                    if (fresh || changed) lastActivityMs = now
                }
                val moving = now - lastActivityMs < params.activeWindowMs
                updateMotion(now)
                pollPressSource()
                // Gate the capture, not just the invalidate: re-recording a live node schedules a frame itself.
                val minGap = if (moving) 0L else params.idleIntervalMs
                if (now - lastCaptureMs >= minGap) {
                    lastCaptureMs = now
                    if (capture.capture()) {
                        if (moving) invalidate() else postInvalidateDelayed(params.idleIntervalMs)
                    }
                }
            }
        } catch (t: Throwable) {
            if (!loggedPreDrawThrow) {
                loggedPreDrawThrow = true
                Log.w("WaThemer.GlassView", "pre-draw capture threw, frame skipped", t)
            }
        }
        true // never cancel the host's frame
    }

    private var loggedPreDrawThrow = false

    /** Asked each pre-draw; a source that changes without scrolling, a photo's zoom, counts as activity. */
    var sourceChanged: (() -> Boolean)? = null

    /** Opt-in: no capture while the pane is wholly off-screen sideways. */
    var skipOffscreen = false

    private var lastCaptureMs = 0L

    /** This pane's screen position from the last pre-draw; the move check and drawClarity's placement both read it. */
    private val screenLoc = IntArray(2)

    /** Last screen position we captured at. See the move check in [preDrawListener]. */
    private var lastScreenX = Int.MIN_VALUE
    private var lastScreenY = Int.MIN_VALUE

    // ── Idle throttling ────────────────────────────────────────────────────────────────
    // Idle over-renders; slow it, never stop it, and the heartbeat covers unseen invalidates.

    private var lastActivityMs = 0L

    // Scroll only: a global-layout listener never lets the throttle engage.
    private val activityListener = ViewTreeObserver.OnScrollChangedListener {
        val now = SystemClock.uptimeMillis()
        lastScrollMs = now
        // Another view's scroll leaves a pane with nothing live behind it unchanged; pre-draw watches what it does show.
        if (!(stillSkipsScroll && backdrop == null)) lastActivityMs = now
    }

    /** Scroll only, a separate clock: attach and resize must not read as motion or panes appear bright. */
    private var lastScrollMs = 0L

    /** The wallpaper views as last seen, [SIG_FIELDS] ints each: size, screen position, visibility, alpha, picture, dim colour. */
    private var underlaySig = IntArray(0)
    private val sigLoc = IntArray(2)

    /** Updates the signature in place and says whether any field of it changed. */
    private fun underlayChanged(): Boolean {
        val u = capture.underlay
        var changed = false
        if (underlaySig.size != u.size * SIG_FIELDS) {
            underlaySig = IntArray(u.size * SIG_FIELDS)
            changed = true
        }
        for (i in u.indices) {
            val v = u[i]
            v.getLocationOnScreen(sigLoc)
            val b = i * SIG_FIELDS
            changed = sig(b, v.width) or changed
            changed = sig(b + 1, v.height) or changed
            changed = sig(b + 2, sigLoc[0]) or changed
            changed = sig(b + 3, sigLoc[1]) or changed
            changed = sig(b + 4, v.visibility) or changed
            changed = sig(b + 5, java.lang.Float.floatToRawIntBits(v.alpha)) or changed
            changed = sig(b + 6, System.identityHashCode((v as? ImageView)?.drawable)) or changed
            changed = sig(b + 7, (v.background as? ColorDrawable)?.color ?: 0) or changed
        }
        return changed
    }

    private fun sig(i: Int, value: Int): Boolean {
        if (underlaySig[i] == value) return false
        underlaySig[i] = value
        return true
    }

    init {
        // A ViewGroup skips onDraw unless told; the backdrop draws there to land under our children.
        setWillNotDraw(false)

        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, params.cornerRadius)
            }
        }
        // GPU clip to the rounded outline; a clipPath in onDraw would allocate on the draw path.
        clipToOutline = true

        params.onChanged = {
            // Comparing every uniform costs more than the rebuild it avoids; just flag stale.
            capture.effectDirty = true
            // Captured at once, not a heartbeat late: still glass takes no capture from other views' scrolls.
            if (stillSkipsScroll) lastActivityMs = SystemClock.uptimeMillis()
            clarityValid = false
            invalidateLight()
            invalidateOutline()
            invalidate()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        capture.register()
        viewTreeObserver.addOnPreDrawListener(preDrawListener)
        viewTreeObserver.addOnScrollChangedListener(activityListener)
        // Attach counts as activity, so the first frames are live rather than a heartbeat late.
        lastActivityMs = SystemClock.uptimeMillis()
        // Once per pane; a pane handed a materialize before attach has its own driver, and one attached hidden would assemble unseen.
        if (assembleOnAppear && !appeared && materialize >= 1f && isShown) {
            appeared = true
            materializeIn(APPEAR_MS)
        }
    }

    private var appeared = false

    override fun onDetachedFromWindow() {
        viewTreeObserver.removeOnPreDrawListener(preDrawListener)
        viewTreeObserver.removeOnScrollChangedListener(activityListener)
        materializeAnim?.cancel()
        pressAnim?.cancel()
        capture.unregister()
        capture.release()
        super.onDetachedFromWindow()
    }

    /** The light program on a Paint, drawn at full resolution after the blur; the highlight must not blur. */
    private val lightPaint = Paint()
    private var lightValid = false

    /** This view's own light shader, never shared: uniforms live on it, so sharing means last writer wins. */
    private val lightShader: RuntimeShader? by lazy {
        if (GlassShader.supported) GlassShader.newLightShader() else null
    }

    private fun invalidateLight() { lightValid = false }

    // ── Dynamic response ───────────────────────────────────────────────────────────────
    // Held here, not in params, whose setters rebuild the refraction chain; wall-clock because frames are uneven.
    private var motion = 0f

    /** Decay is clamped to activeWindowMs: a longer decay stalls part-way, then snaps at a heartbeat. */
    private fun updateMotion(now: Long) {
        val decay = minOf(params.motionDecayMs, params.activeWindowMs)
        val off = params.motionSpecGain <= 0f && params.motionFresnelGain <= 0f
        val target = if (decay <= 0L || off || lastScrollMs == 0L) {
            0f    // lastScrollMs 0 means nothing has scrolled yet: at rest, not at full motion
        } else {
            // Squared: fast fall while the eye is on the motion, flat landing, and the 0.01 gate stops the pushes sooner.
            val lin = (1f - (now - lastScrollMs).toFloat() / decay.toFloat()).coerceIn(0f, 1f)
            lin * lin
        }
        // A threshold; exact equality would re-push every light uniform on every frame of the decay.
        if (abs(target - motion) < 0.01f) return
        motion = target
        invalidateLight()
        invalidate()
    }

    // ── Materialize ─────────────────────────────────────────────────────────────────────
    /** 0 no material, 1 settled. Drives transmission, tint and lighting; never View.alpha, which flattens the material into a decal. */
    private var materialize = 1f
    private var materializeAnim: ValueAnimator? = null

    /** Armed by [materializeIn]; the lighting rig swings home while the material assembles. */
    private var appearSweep = false

    /** Exposed so a restore can test the material a hide fade dissolved. */
    val materialized: Float get() = materialize

    fun setMaterialize(p: Float) {
        val v = p.coerceIn(0f, 1f)
        if (v == materialize) return
        materialize = v
        if (v >= 1f) appearSweep = false
        // The transmission leads the lighting: the backdrop swells in first, the rim strikes last.
        capture.setContentAlpha((v * 1.4f).coerceAtMost(1f))
        capture.setRimAlpha(v)
        invalidateLight()
        invalidate()
    }

    /** Its own clock: the pre-draw poll idles at the heartbeat, far below animation rate. */
    fun materializeTo(target: Float, durationMs: Long) {
        materializeAnim?.cancel()
        if (durationMs <= 0L) {
            setMaterialize(target)
            setLens(target)
            return
        }
        materializeAnim = ValueAnimator.ofFloat(materialize, target).apply {
            duration = durationMs
            addUpdateListener {
                val v = it.animatedValue as Float
                setMaterialize(v)
                setLens(v)
            }
            start()
        }
    }

    /** From an animation only: this rebuilds the capture's chain, and the info header scrubs materialize from a scroll. */
    private fun setLens(v: Float) {
        if (!assembleOnAppear) return
        capture.setLensScale(v)
        // The capture is placed by position and gated on movement; a bend that is changing has to count as moving.
        lastActivityMs = SystemClock.uptimeMillis()
    }

    /** Appear by assembling rather than fading. */
    fun materializeIn(durationMs: Long) {
        appearSweep = true
        setMaterialize(0f)
        materializeTo(1f, durationMs)
    }

    /** One definition each for shader and [flatInteriorColor]; disagreeing on Fresnel steps the band edge. */
    private fun effSpecStrength(): Float =
        params.specStrength * (1f + params.motionSpecGain * motion) * materialize * materialize

    private fun effFresnelStrength(): Float =
        params.fresnelStrength * (1f + params.motionFresnelGain * motion) * materialize * materialize

    private fun ensureLight(): Boolean {
        val rs = lightShader ?: return false
        if (lightValid) return true
        if (width <= 0 || height <= 0) return false
        lightValid = true
        // The appear sweep rotates both spec lights home as the rim strikes; rimMask keeps the plateau exact.
        var l1x = params.lightX
        var l1y = params.lightY
        var l2x = params.light2X
        var l2y = params.light2Y
        if (appearSweep && materialize < 1f) {
            val a = (1f - materialize) * SWEEP_RADIANS
            val c = cos(a)
            val s = sin(a)
            l1x = params.lightX * c - params.lightY * s
            l1y = params.lightX * s + params.lightY * c
            l2x = params.light2X * c - params.light2Y * s
            l2y = params.light2X * s + params.light2Y * c
        }
        GlassShader.applyLightUniforms(
            rs, params, width, height,
            specStrength = effSpecStrength(),
            fresnelStrength = effFresnelStrength(),
            density = resources.displayMetrics.density,
            tintScale = materialize,
            light1X = l1x,
            light1Y = l1y,
            light2X = l2x,
            light2Y = l2y,
            pressX = pressX,
            pressY = pressY,
            pressAmp = pressAmp,
            pressRadiusPx = PRESS_RADIUS_DP * resources.displayMetrics.density,
        )
        lightPaint.shader = rs
        return true
    }

    // ── Press response ─────────────────────────────────────────────────────────────────
    // Additive on the light scalar only; a normal bump hits the pow(1-n.z,5) rim exactly as microAmp did.
    private var pressAmp = 0f
    private var pressX = 0f
    private var pressY = 0f
    private var pressAnim: ValueAnimator? = null
    private var pressSourceRef: WeakReference<View>? = null
    private var pressWasDown = false
    private val pressLoc = IntArray(2)

    /** Polled in pre-draw: while this view's isPressed is set, light pools at its centre. */
    var pressSource: View?
        get() = pressSourceRef?.get()
        set(value) {
            pressSourceRef = if (value == null) null else WeakReference(value)
        }

    private fun setPressAmp(a: Float) {
        if (a == pressAmp) return
        pressAmp = a
        invalidateLight()
        invalidate()
    }

    private fun animatePress(target: Float, durationMs: Long) {
        pressAnim?.cancel()
        pressAnim = ValueAnimator.ofFloat(pressAmp, target).apply {
            duration = durationMs
            addUpdateListener { setPressAmp(it.animatedValue as Float) }
            start()
        }
    }

    /** Its own invalidate; the moving flag would make a press re-record the backdrop. */
    fun pressAt(x: Float, y: Float) {
        pressX = x
        pressY = y
        animatePress(PRESS_AMP, PRESS_IN_MS)
    }

    fun releasePress() {
        if (pressAmp <= 0f && pressAnim == null) return
        animatePress(0f, PRESS_OUT_MS)
    }

    /** Edge-detects the source's pressed state; two field reads at rest. */
    private fun pollPressSource() {
        val s = pressSourceRef?.get() ?: return
        val down = s.isPressed
        if (down == pressWasDown) return
        pressWasDown = down
        if (down) {
            s.getLocationOnScreen(pressLoc)
            val sx = pressLoc[0] + s.width / 2f
            val sy = pressLoc[1] + s.height / 2f
            getLocationOnScreen(pressLoc)
            pressAt(sx - pressLoc[0], sy - pressLoc[1])
        } else {
            releasePress()
        }
    }

    private val flatPaint = Paint()

    // ── Crisp rim ──────────────────────────────────────────────────────────────────────
    // The band again from the sharp wallpaper, under the light pass; wallpaper-only panes, since a live source has no sharp bitmap.

    /** This pane's own rim shader; uniforms live on it. */
    private val clarityShader: RuntimeShader? by lazy {
        if (GlassShader.supported) GlassShader.newRimShader() else null
    }
    private val clarityPaint = Paint()
    private var clarityContent: BitmapShader? = null
    private var clarityContentOf: Bitmap? = null
    private val clarityMatrix = Matrix()
    private var clarityW = -1
    private var clarityH = -1
    private var clarityDetail = -1f
    private var clarityDim = -1f
    private var clarityValid = false

    private fun drawClarity(canvas: Canvas) {
        if (params.detail <= 0f || backdrop != null || width <= 0 || height <= 0 || !capture.hasContent) return
        // A pane expanded past its band on every side is all plateau; the program would return nothing for its price.
        val expand = minOf(minOf(params.edgeExpandLeft, params.edgeExpandRight), minOf(params.edgeExpandTop, params.edgeExpandBottom))
        if (expand >= GlassShader.effectiveBevel(params, width, height)) return
        val rs = clarityShader ?: return
        val rec = wallpaperRecordFor?.invoke(this) ?: return
        val src = rec.src
        val place = rec.srcPlacement ?: return
        if (src.isRecycled) return
        val dim = rec.dimAlpha / 255f
        // Scaled by materialize like the rim stroke, so the sharp edge assembles with the frost instead of arriving first.
        val detail = params.detail * materialize
        if (!clarityValid || width != clarityW || height != clarityH || detail != clarityDetail || dim != clarityDim) {
            clarityW = width
            clarityH = height
            clarityDetail = detail
            clarityDim = dim
            clarityValid = true
            GlassShader.applyRimUniforms(rs, params, width, height, dim, detail)
        }
        var cs = clarityContent
        if (cs == null || clarityContentOf !== src) {
            cs = BitmapShader(src, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
            // Linear, or the child samples nearest whatever the paint says.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) cs.filterMode = BitmapShader.FILTER_MODE_LINEAR
            clarityContent = cs
            clarityContentOf = src
        }
        // Source to screen, then screen to this pane; screenLoc is refreshed every pre-draw. Bind after the matrix, as the painter does.
        clarityMatrix.set(place)
        clarityMatrix.postTranslate(-screenLoc[0].toFloat(), -screenLoc[1].toFloat())
        cs.setLocalMatrix(clarityMatrix)
        rs.setInputShader("content", cs)
        clarityPaint.shader = rs
        val w = width.toFloat()
        val h = height.toFloat()
        val band = ceil(GlassShader.effectiveBevel(params, width, height) + 2f)
        if (band * 2f + 4f >= minOf(w, h)) {
            canvas.drawRect(0f, 0f, w, h, clarityPaint)
            return
        }
        canvas.drawRect(0f, 0f, w, band, clarityPaint)
        canvas.drawRect(0f, h - band, w, h, clarityPaint)
        canvas.drawRect(0f, band, band, h - band, clarityPaint)
        canvas.drawRect(w - band, band, w, h - band, clarityPaint)
    }

    /** Shade only the bevel band; the plateau gets the exact constant, sparing a whole-surface shader pass. */
    private fun drawLight(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        // Ceiled, with slack, so the translucent rects abut exactly: a fractional edge leaves a row bare and an overlap tints one twice.
        val band = ceil(GlassShader.effectiveBevel(params, width, height) + 2f)

        // All plateau, so the program would return this one colour at every pixel.
        if (allPlateau()) {
            val c = flatInteriorColor()
            if (c ushr 24 != 0) {
                flatPaint.color = c
                canvas.drawRect(0f, 0f, w, h, flatPaint)
            }
            return
        }
        // Otherwise a fading or expanded surface cannot use the shortcut: a flat rect cannot ramp its alpha.
        val fading = params.fadeTopLenPx > 0f ||
            params.edgeExpandLeft > 0f || params.edgeExpandTop > 0f ||
            params.edgeExpandRight > 0f || params.edgeExpandBottom > 0f
        // A pressed pane's pool crosses the plateau and a pane a few pixels tall has almost none, so both run the program everywhere.
        if (fading || pressAmp > 0f || band * 2f + 4f >= minOf(w, h)) {
            canvas.drawRect(0f, 0f, w, h, lightPaint)
            return
        }
        canvas.drawRect(0f, 0f, w, band, lightPaint)                 // top
        canvas.drawRect(0f, h - band, w, h, lightPaint)              // bottom
        canvas.drawRect(0f, band, band, h - band, lightPaint)        // left
        canvas.drawRect(w - band, band, w, h - band, lightPaint)     // right

        val c = flatInteriorColor()
        if (c ushr 24 != 0) {
            flatPaint.color = c
            // Abutting again; see the note on band above.
            canvas.drawRect(band, band, w - band, h - band, flatPaint)
        }
    }

    /** Every pixel is plateau: expanded past the bevel on every side by the shader's own margin, with no corner, fade or press. */
    private fun allPlateau(): Boolean {
        if (params.fadeTopLenPx > 0f || pressAmp > 0f || params.cornerRadius != 0f) return false
        val rr = params.cornerRadii
        if (rr != null && rr.any { it != 0f }) return false
        val bevel = GlassShader.effectiveBevel(params, width, height)
        val k = (bevel * 0.35f).coerceIn(2f, 64f)
        val expand = minOf(
            minOf(params.edgeExpandLeft, params.edgeExpandRight),
            minOf(params.edgeExpandTop, params.edgeExpandBottom),
        )
        return expand >= bevel + k / 4f - 0.5f
    }

    /** The exact plateau colour the light program returns: f0 survives there, the premultiplied rgb must be un-premultiplied for a Paint, and it must read [effFresnelStrength] or the edge steps. */
    private fun flatInteriorColor(): Int {
        // The same tint scale the shader gets, or the band edge steps while a pane materializes.
        val ta = ((params.tintColor ushr 24) and 0xFF) / 255f * materialize
        val tr = ((params.tintColor ushr 16) and 0xFF) / 255f
        val tg = ((params.tintColor ushr 8) and 0xFF) / 255f
        val tb = (params.tintColor and 0xFF) / 255f
        val light = (0.04f * effFresnelStrength()).coerceIn(0f, 1f)
        val a = (ta + light).coerceIn(0f, 1f)
        if (a <= 0f) return 0
        fun ch(t: Float): Int {
            val pm = (t * ta + light).coerceIn(0f, 1f)
            return ((pm / a).coerceIn(0f, 1f) * 255f + 0.5f).toInt()
        }
        return ((a * 255f + 0.5f).toInt() shl 24) or (ch(tr) shl 16) or (ch(tg) shl 8) or ch(tb)
    }

    private val rimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private var rimW = -1
    private var rimH = -1
    private var rimAngle = Float.NaN
    private var rimColor = 0
    private var rimWidth = -1f

    /** A gradient-shaded line on the silhouette. Rebuilt only when size, angle, colour or width move. */
    private fun drawRim(canvas: Canvas) {
        if (!params.rimEnabled) return
        val px = params.rimStrokePx
        if (px <= 0f) return
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        if (rimW != width || rimH != height || rimAngle != params.rimStrokeAngle ||
            rimColor != params.rimStrokeColor || rimWidth != px
        ) {
            rimW = width
            rimH = height
            rimAngle = params.rimStrokeAngle
            rimColor = params.rimStrokeColor
            rimWidth = px
            rimPaint.strokeWidth = px
            val rad = Math.toRadians(rimAngle.toDouble())
            // Half the box projected onto the axis, so the ramp spans the surface whatever the angle.
            val ext = (abs(cos(rad)) * w + abs(sin(rad)) * h) / 2.0
            val dx = (cos(rad) * ext).toFloat()
            val dy = (sin(rad) * ext).toFloat()
            // Lit at both ends of the axis, clear across the middle.
            rimPaint.shader = LinearGradient(
                w / 2f - dx, h / 2f - dy, w / 2f + dx, h / 2f + dy,
                intArrayOf(rimColor, rimColor and 0x00FFFFFF, rimColor),
                floatArrayOf(0f, 0.5f, 1f),
                Shader.TileMode.CLAMP,
            )
        }
        // Scaled by materialize, or the rim arrives at full strength while the pane fades up.
        rimPaint.alpha = (255f * materialize).toInt().coerceIn(0, 255)
        // Inset half the width; clipToOutline eats the outer half otherwise.
        val inset = px / 2f
        val r = (params.cornerRadius - inset).coerceAtLeast(0f)
        canvas.drawRoundRect(inset, inset, w - inset, h - inset, r, r, rimPaint)
    }

    private fun deriveBevel(w: Int, h: Int) {
        val frac = params.bevelFraction
        if (frac <= 0f || w <= 0 || h <= 0) return
        params.bevelThickness = (minOf(w, h) * frac).coerceAtLeast(1f)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        deriveBevel(w, h)
        invalidateLight()
        // A resize must not wait for a heartbeat: anything already recorded is the wrong size.
        lastActivityMs = SystemClock.uptimeMillis()
        capture.effectDirty = true
        // Without this the outline clips at the old size and the pane draws cut short after a resize.
        invalidateOutline()
        invalidate()
    }

    companion object {
        /** Half a turn (pi): the arcs start opposite their homes and sweep in as the rim strikes. */
        private const val SWEEP_RADIANS = 3.1415927f
        /** The light added at the pool's centre; chosen by eye. */
        private const val PRESS_AMP = 0.12f
        private const val PRESS_IN_MS = 80L
        private const val PRESS_OUT_MS = 240L
        /** Finger-sized pool: buttons sit inside it whole, cards get a local glow. */
        private const val PRESS_RADIUS_DP = 64f

        /** Surfaces assemble their lens as they appear rather than arriving whole; set at install. */
        @JvmStatic var assembleOnAppear: Boolean = false

        /** Glass with nothing live behind it ignores other views' scrolling and watches its wallpaper views instead; set at install. */
        @JvmStatic var stillSkipsScroll: Boolean = false

        private const val SIG_FIELDS = 8

        const val APPEAR_MS = 220L

        /** A view's window wallpaper record, for the rim pass; the hook sets it once, so the engine never imports the hook. */
        @JvmStatic var wallpaperRecordFor: ((View) -> WallpaperRecord?)? = null
    }

    override fun onDraw(canvas: Canvas) {
        if (!params.enabled) return

        // drawRenderNode needs a RecordingCanvas; on a software canvas degrade to tint instead of crashing.
        val recording = canvas as? RecordingCanvas
        if (recording != null) {
            capture.draw(recording)
            drawClarity(canvas)
        }

        // Full-res light over the blur; the RuntimeShader Paint needs the hardware-canvas check too.
        if (recording != null && ensureLight()) {
            drawLight(canvas)
        } else if (params.tintColor ushr 24 != 0) {
            canvas.drawColor(params.tintColor)
        }
        // Over the light pass, and plain Canvas so the software path keeps it.
        drawRim(canvas)
    }
}
