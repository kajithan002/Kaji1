# WaThemer video wallpaper fork

This source fork adds MP4 video wallpapers to both the global Wallpaper screen and the per-chat wallpaper picker.

## Behaviour

- MP4 only.
- Maximum duration: 30 seconds (longer clips are rejected, not trimmed).
- Maximum file size: 64 MB.
- Playback is muted and loops continuously.
- A full-screen `TextureView` is inserted behind WhatsApp's chat content.
- The video layer fills the wallpaper view bounds; it does not use the image wallpaper's `CENTER_CROP` mode.
- Playback pauses when a WhatsApp Activity pauses and the player is released when that Activity is destroyed.
- Existing still-image wallpaper selection remains unchanged.
- Video thumbnails show the first frame in WaThemer's settings screens.

## Build

Requirements are the same as the project: JDK 17+, Android SDK platform 36, and the Gradle 8.13 distribution.

From the project root:

```bash
./gradlew assembleDebug
```

The debug APK is written to `app/build/outputs/apk/debug/`.

## Important signing note

The debug APK is signed with the local debug key. It will not install as an in-place update over an existing WaThemer release if the signing certificates differ. Back up the app's settings first; installing a differently signed build may require uninstalling the existing app and will clear its app data. A release build also needs a keystore configured in Gradle properties.

## Verification status

The source changes were reviewed and Kotlin syntax parsing found no parser errors. A full Android build could not be run in this environment because the Gradle 8.13 distribution and Android SDK are not installed here, and the environment cannot download them. The generated source package is therefore a modified project, not a prebuilt/installable APK.
